import { supabase } from '../lib/supabase';

export async function sendEmail(
  to: string,
  subject: string,
  body: string,
  studentId?: string,
  submissionId?: string,
  warningNumber?: number
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to,
        subject,
        body,
        studentId,
        submissionId,
        warningNumber,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Failed to send email');
    }

    return {
      success: true,
      messageId: data.messageId,
    };
  } catch (error: any) {
    console.error('Error sending email:', error);
    return {
      success: false,
      error: error.message || 'Failed to send email',
    };
  }
}

export async function sendEmailAndRecord(
  studentId: string,
  submissionId: string,
  warningNumber: number,
  subject: string,
  body: string,
  studentEmail: string,
  onDebugLog?: (message: string) => void
): Promise<void> {
  onDebugLog?.(`STEP 13: Sending email to ${studentEmail}`);
  const result = await sendEmail(
    studentEmail,
    subject,
    body,
    studentId,
    submissionId,
    warningNumber
  );

  if (!result.success) {
    onDebugLog?.(`ERROR sending email: ${result.error}`);
    throw new Error(result.error || 'Failed to send email');
  }
  onDebugLog?.(`Email sent successfully - Message ID: ${result.messageId || 'N/A'}`);

  onDebugLog?.(`STEP 14: Recording warning in database`);
  const { data: student } = await supabase
    .from('students')
    .select('*')
    .eq('id', studentId)
    .maybeSingle();

  if (!student) {
    onDebugLog?.(`ERROR: Student not found with ID ${studentId}`);
    throw new Error('Student not found');
  }

  const { error: warningError } = await supabase.from('warnings').insert({
    student_id: studentId,
    submission_id: submissionId,
    warning_number: warningNumber,
    email_content: `Subject: ${subject}\n\n${body}`,
  });

  if (warningError) {
    onDebugLog?.(`ERROR inserting warning: ${warningError.message}`);
    throw warningError;
  }
  onDebugLog?.(`Warning record created successfully`);

  onDebugLog?.(`STEP 15: Updating student warning count`);
  const { error: updateError } = await supabase
    .from('students')
    .update({ total_warnings: student.total_warnings + 1 })
    .eq('id', studentId);

  if (updateError) {
    onDebugLog?.(`ERROR updating student: ${updateError.message}`);
    throw updateError;
  }
  onDebugLog?.(`Student warning count updated: ${student.total_warnings} -> ${student.total_warnings + 1}`);
  onDebugLog?.(`STEP 16: Email generation and sending complete! ✓`);
}
