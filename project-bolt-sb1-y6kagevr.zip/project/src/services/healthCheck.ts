import { supabase } from '../lib/supabase';

export interface HealthCheckResult {
  isHealthy: boolean;
  error?: string;
  details?: {
    canConnect: boolean;
    tablesAccessible: boolean;
    studentCount?: number;
  };
}

export async function checkDatabaseHealth(): Promise<HealthCheckResult> {
  try {
    // Test 1: Basic connection
    const { error: connectionError } = await supabase
      .from('students')
      .select('id', { count: 'exact', head: true });

    if (connectionError) {
      return {
        isHealthy: false,
        error: `Database connection failed: ${connectionError.message}`,
        details: {
          canConnect: false,
          tablesAccessible: false,
        },
      };
    }

    // Test 2: Read data
    const { data, error: readError, count } = await supabase
      .from('students')
      .select('id', { count: 'exact', head: true });

    if (readError) {
      return {
        isHealthy: false,
        error: `Cannot read from database: ${readError.message}`,
        details: {
          canConnect: true,
          tablesAccessible: false,
        },
      };
    }

    return {
      isHealthy: true,
      details: {
        canConnect: true,
        tablesAccessible: true,
        studentCount: count ?? 0,
      },
    };
  } catch (error) {
    return {
      isHealthy: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
      details: {
        canConnect: false,
        tablesAccessible: false,
      },
    };
  }
}
