import emailAddressData from '../data/email-addresses.csv?raw';

interface EmailRecord {
  lastName: string;
  firstName: string;
  username: string;
  gNumber: string;
  email: string;
}

let emailMap: Map<string, string> | null = null;

function parseEmailCSV(): Map<string, string> {
  const lines = emailAddressData.split('\n').filter(line => line.trim());
  const map = new Map<string, string>();

  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const parts = line.split(',');

    if (parts.length >= 5) {
      const lastName = parts[0].trim();
      const firstName = parts[1].trim();
      const email = parts[4].trim();

      if (email && email.includes('@')) {
        // Create lookup key from full name (case insensitive)
        const fullName = `${firstName} ${lastName}`.toLowerCase();
        map.set(fullName, email);

        // Also store by last name, first name format
        const reverseName = `${lastName}, ${firstName}`.toLowerCase();
        map.set(reverseName, email);
      }
    }
  }

  return map;
}

export function getEmailMap(): Map<string, string> {
  if (!emailMap) {
    emailMap = parseEmailCSV();
  }
  return emailMap;
}

export function lookupEmail(studentName: string): string | null {
  const map = getEmailMap();
  const normalizedName = studentName.toLowerCase().trim();

  // Try direct lookup
  if (map.has(normalizedName)) {
    return map.get(normalizedName)!;
  }

  // Try reversing first/last name order
  const parts = normalizedName.split(/\s+/);
  if (parts.length >= 2) {
    const firstName = parts[0];
    const lastName = parts.slice(1).join(' ');
    const reversed = `${lastName}, ${firstName}`;

    if (map.has(reversed)) {
      return map.get(reversed)!;
    }
  }

  return null;
}

export function getAllEmails(): EmailRecord[] {
  const lines = emailAddressData.split('\n').filter(line => line.trim());
  const records: EmailRecord[] = [];

  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const parts = line.split(',');

    if (parts.length >= 5) {
      const email = parts[4].trim();
      if (email && email.includes('@')) {
        records.push({
          lastName: parts[0].trim(),
          firstName: parts[1].trim(),
          username: parts[2].trim(),
          gNumber: parts[3].trim(),
          email: email
        });
      }
    }
  }

  return records;
}
