import { supabase } from '../lib/supabase';

export interface EmailData {
  studentName: string;
  studentEmail: string;
  postDate: string;
  discussionTitle: string;
  redFlags: string[];
  explanation: string;
  postQuotes: string[];
  warningNumber: number;
  previousWarningDates: string[];
}

export async function generateEmailContent(
  studentId: string,
  submissionId: string
): Promise<{ subject: string; body: string; warningNumber: number }> {
  const { data: student, error: studentError } = await supabase
    .from('students')
    .select('*')
    .eq('id', studentId)
    .single();

  if (studentError) {
    // removed debug log(`ERROR fetching student: ${studentError.message}`);
    throw studentError;
  }
  // removed debug log(`Student found: ${student?.name}`);

  // removed debug log(`STEP 3: Fetching submission data - ID: ${submissionId}`);
  const { data: submission, error: submissionError } = await supabase
    .from('submissions')
    .select('*, discussions(*)')
    .eq('id', submissionId)
    .single();

  if (submissionError) {
    // removed debug log(`ERROR fetching submission: ${submissionError.message}`);
    throw submissionError;
  }
  // removed debug log(`Submission found, post length: ${submission?.post_text?.length || 0} chars`);

  // removed debug log(`STEP 4: Fetching analysis results`);
  const { data: analysis, error: analysisError } = await supabase
    .from('analysis_results')
    .select('*')
    .eq('submission_id', submissionId)
    .single();

  if (analysisError) {
    // removed debug log(`ERROR fetching analysis: ${analysisError.message}`);
    throw analysisError;
  }
  // removed debug log(`Analysis found - Red flags: ${analysis?.red_flags?.length || 0}`);

  // removed debug log(`STEP 5: Fetching previous warnings`);
  const { data: previousWarnings } = await supabase
    .from('warnings')
    .select('*')
    .eq('student_id', studentId)
    .order('sent_date', { ascending: false });

  const warningNumber = (previousWarnings?.length || 0) + 1;
  // removed debug log(`Previous warnings: ${previousWarnings?.length || 0}, This will be warning #${warningNumber}`);

  // removed debug log(`STEP 6: Fetching email template for warning level ${Math.min(warningNumber, 4)}`);
  const { data: template, error: templateError } = await supabase
    .from('email_templates')
    .select('*')
    .eq('warning_level', Math.min(warningNumber, 4))
    .single();

  if (templateError) {
    // removed debug log(`ERROR fetching template: ${templateError.message}`);
    throw templateError;
  }
  // removed debug log(`Template found: ${template?.subject}`);

  if (!student || !submission || !analysis || !template) {
    const missing = [];
    if (!student) missing.push('student');
    if (!submission) missing.push('submission');
    if (!analysis) missing.push('analysis');
    if (!template) missing.push('template');
    throw new Error(`Missing required data for email generation: ${missing.join(', ')}`);
  }

  // removed debug log(`STEP 7: Fetching instructor settings`);
  const { data: settingsData } = await supabase
    .from('settings')
    .select('*')
    .eq('key', 'instructor_name')
    .single();

  const instructorInfo = settingsData?.value || {
    name: 'Instructor Name',
    title: 'Assistant Professor',
    institution: 'University Name',
  };
  // removed debug log(`Instructor: ${instructorInfo.name}`);

  // removed debug log(`STEP 8: Extracting quotes from post`);
  const postQuotes = extractQuotes(submission.post_text);
  // removed debug log(`Extracted ${postQuotes.length} quotes`);

  // removed debug log(`STEP 9: Validating discussion title`);
  let discussionTitle = (submission as any).discussions?.title || '';
  discussionTitle = validateDiscussionTitle(discussionTitle, submission.post_timestamp);
  // removed debug log(`Discussion title: "${discussionTitle}"`);

  // removed debug log(`STEP 10: Building email data object`);
  const emailData: EmailData = {
    studentName: student.name.split(' ')[0],
    studentEmail: student.email,
    postDate: submission.post_timestamp ? new Date(submission.post_timestamp).toLocaleDateString() : 'Unknown',
    discussionTitle,
    redFlags: analysis.red_flags || [],
    explanation: analysis.explanation,
    postQuotes,
    warningNumber,
    previousWarningDates:
      previousWarnings?.map((w) => new Date(w.sent_date).toLocaleDateString()) || [],
  };

  // removed debug log(`STEP 11: Populating email template`);
  let body = template.body_template;

  body = body.replace(/\{\{student_name\}\}/g, emailData.studentName);
  body = body.replace(/\{\{post_date\}\}/g, emailData.postDate);

  const titleForEmail = emailData.discussionTitle === 'that discussion'
    ? emailData.discussionTitle
    : `the discussion "${emailData.discussionTitle}"`;

  body = body.replace(/\{\{discussion_title\}\}/g, titleForEmail);
  body = body.replace(/\{\{explanation\}\}/g, emailData.explanation);
  body = body.replace(/\{\{instructor_name\}\}/g, instructorInfo.name);

  const redFlagsText =
    emailData.redFlags.length > 0
      ? emailData.redFlags.map((flag) => `- ${flag}`).join('\n')
      : 'Multiple indicators of AI assistance were detected.';
  body = body.replace(/\{\{red_flags\}\}/g, redFlagsText);

  const quotesText =
    emailData.postQuotes.length > 0
      ? emailData.postQuotes.map((quote) => `"${quote}"`).join('\n\n')
      : '';
  body = body.replace(/\{\{quotes\}\}/g, quotesText);

  if (emailData.previousWarningDates.length > 0) {
    body = body.replace(
      /\{\{previous_warning_date\}\}/g,
      emailData.previousWarningDates[0]
    );
    body = body.replace(
      /\{\{previous_warning_dates\}\}/g,
      emailData.previousWarningDates.join(', ')
    );
  }

  // removed debug log(`STEP 12: Email generation complete - Subject: "${template.subject}"`);

  return {
    subject: template.subject,
    body,
    warningNumber,
  };
}

function validateDiscussionTitle(title: string, postTimestamp: string | null): string {
  // List of UI elements and invalid patterns that indicate a bad title
  const invalidPatterns = [
    /[⚙🔔📝▾]/,
    /options/i,
    /back to/i,
    /view all/i,
    /add response/i,
    /counter points/i,
    /supporting points/i,
    /expand all/i,
    /help center/i,
    /packback/i,
  ];

  // Check if the title contains any invalid patterns
  const hasInvalidPattern = invalidPatterns.some(pattern => pattern.test(title));

  // Check if the title is too short or generic
  const isTooShort = title.trim().length < 10;
  const isGeneric = title === 'Packback Discussion' || title === 'Unknown Discussion' || !title;

  // If the title looks invalid, return a simple instruction without repeating the date
  if (hasInvalidPattern || isTooShort || isGeneric) {
    return 'that discussion';
  }

  // Clean up the title by removing any stray symbols
  return title
    .replace(/[⚙🔔📝▾]/g, '')
    .trim();
}

function extractQuotes(postText: string): string[] {
  const sentences = postText.match(/[^.!?]+[.!?]+/g) || [];
  const quotes: string[] = [];

  // UI elements and patterns to exclude from quotes
  const excludePatterns = [
    /Response shared by/i,
    /Response Details/i,
    /Back to Full/i,
    /You're currently viewing/i,
    /question has received/i,
    /Student \d+/i,
    /Expand All/i,
    /Add Response/i,
    /View All/i,
    /Counter Points/i,
    /Supporting Points/i,
    /received\s+\d+/i,
    /\d+\s+points?/i,
    /^\s*\d+\s*$/,  // Just numbers
    /⚙|🔔|📝|▾/,  // UI icons
  ];

  // AI-characteristic terms and patterns
  const aiIndicators = [
    'deontological',
    'consequentialist',
    'moral agency',
    'ethical framework',
    'categorical imperative',
    'furthermore',
    'moreover',
    'thus',
    'hence',
    'thereby',
    'notwithstanding',
  ];

  const isValidQuote = (sentence: string): boolean => {
    // Filter out UI elements
    if (excludePatterns.some(pattern => pattern.test(sentence))) {
      return false;
    }

    // Filter out very short sentences (likely fragments)
    if (sentence.trim().length < 30) {
      return false;
    }

    // Filter out sentences that are mostly numbers or special characters
    const alphaRatio = (sentence.match(/[a-zA-Z]/g) || []).length / sentence.length;
    if (alphaRatio < 0.6) {
      return false;
    }

    return true;
  };

  // First pass: Look for sentences with AI indicators
  for (const sentence of sentences) {
    if (!isValidQuote(sentence)) continue;

    if (
      aiIndicators.some((term) => sentence.toLowerCase().includes(term.toLowerCase())) ||
      (sentence.length > 100 && !sentence.includes(' I ') && !sentence.includes(' my '))
    ) {
      quotes.push(sentence.trim());
      if (quotes.length >= 2) break;
    }
  }

  // Second pass: If we don't have enough quotes, add the longest valid sentences
  if (quotes.length < 2) {
    const validSentences = sentences
      .filter(isValidQuote)
      .sort((a, b) => b.length - a.length);

    for (const sentence of validSentences) {
      if (!quotes.includes(sentence.trim())) {
        quotes.push(sentence.trim());
        if (quotes.length >= 2) break;
      }
    }
  }

  return quotes;
}
