import { useState, useEffect } from 'react';
import { AlertCircle, MessageSquare, Calendar, CheckCircle, AlertTriangle, Mail, Eye, LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { StudentLogin } from './StudentLogin';

interface Submission {
  id: string;
  discussionTitle: string;
  date: string;
  score: number;
  type: 'question' | 'response';
  redFlags: string[];
  postExcerpt: string;
  emailSent?: boolean;
  emailSubject?: string;
  emailBody?: string;
  emailSentDate?: string;
}

interface EmailLog {
  id: string;
  subject: string;
  body: string;
  sentDate: string;
  warningNumber: number;
  submissionId?: string;
  discussionTitle?: string;
}

interface StudentData {
  name: string;
  gNumber: string;
  section: string;
  submissions: Submission[];
  emails: EmailLog[];
}

export default function StudentPortal() {
  const [loggedInGNumber, setLoggedInGNumber] = useState<string | null>(null);
  const [studentData, setStudentData] = useState<StudentData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedSubmission, setSelectedSubmission] = useState<string | null>(null);
  const [viewingEmail, setViewingEmail] = useState<string | null>(null);
  const [showAllEmails, setShowAllEmails] = useState(false);

  const handleLogin = async (gNumber: string) => {
    setIsLoading(true);
    setError('');

    try {
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('id, name, email, section, g_number')
        .eq('g_number', gNumber)
        .maybeSingle();

      if (studentError) throw studentError;

      if (!student) {
        setError('G-number not found. Please check your G-number or contact your instructor.');
        setIsLoading(false);
        return;
      }

      const { data: submissions, error: submissionsError } = await supabase
        .from('analysis_results')
        .select(`
          id,
          submission_type,
          authenticity_score,
          red_flags,
          submission_text,
          created_at,
          discussions (
            title,
            discussion_date
          ),
          email_logs (
            subject,
            body,
            sent_at
          )
        `)
        .eq('student_id', student.id)
        .order('created_at', { ascending: false });

      if (submissionsError) throw submissionsError;

      const { data: allEmails, error: emailsError } = await supabase
        .from('email_logs')
        .select(`
          id,
          subject,
          body,
          sent_at,
          warning_number,
          submission_id,
          submissions (
            discussions (
              title
            )
          )
        `)
        .eq('student_id', student.id)
        .order('sent_at', { ascending: false });

      if (emailsError) throw emailsError;

      const formattedEmails: EmailLog[] = (allEmails || []).map((email: any) => ({
        id: email.id,
        subject: email.subject,
        body: email.body,
        sentDate: new Date(email.sent_at).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: 'numeric',
          minute: '2-digit'
        }),
        warningNumber: email.warning_number,
        submissionId: email.submission_id,
        discussionTitle: email.submissions?.discussions?.title
      }));

      const formattedSubmissions: Submission[] = (submissions || []).map((sub: any) => {
        const emailLog = sub.email_logs?.[0];
        return {
          id: sub.id,
          discussionTitle: sub.discussions?.title || 'Untitled Discussion',
          date: new Date(sub.created_at).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          }),
          score: sub.authenticity_score || 0,
          type: sub.submission_type || 'response',
          redFlags: sub.red_flags || [],
          postExcerpt: sub.submission_text?.substring(0, 150) || 'No excerpt available',
          emailSent: !!emailLog,
          emailSubject: emailLog?.subject,
          emailBody: emailLog?.body,
          emailSentDate: emailLog?.sent_at ? new Date(emailLog.sent_at).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          }) : undefined
        };
      });

      setStudentData({
        name: student.name,
        gNumber: student.g_number || gNumber,
        section: student.section || 'N/A',
        submissions: formattedSubmissions,
        emails: formattedEmails
      });

      setLoggedInGNumber(gNumber);

      const { error: loginError } = await supabase
        .from('student_logins')
        .insert({
          g_number: gNumber,
          student_name: student.name,
          logged_in_at: new Date().toISOString()
        });

      if (loginError) {
        console.error('Failed to record login:', loginError);
      }

    } catch (err: any) {
      console.error('Login error:', err);
      setError('An error occurred while loading your data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    setLoggedInGNumber(null);
    setStudentData(null);
    setSelectedSubmission(null);
    setViewingEmail(null);
    setShowAllEmails(false);
  };

  if (!loggedInGNumber || !studentData) {
    return <StudentLogin onLogin={handleLogin} />;
  }

  const { name, gNumber, section, submissions, emails } = studentData;

  const averageScore = submissions.reduce((sum, s) => sum + s.score, 0) / submissions.length;
  const flaggedCount = submissions.filter(s => s.score >= 3).length;
  const emailedCount = emails.length;

  const getScoreColor = (score: number) => {
    if (score <= 1) return 'text-green-600 bg-green-50 border-green-200';
    if (score <= 3) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  const getScoreLabel = (score: number) => {
    if (score <= 1) return 'Authentic';
    if (score === 2) return 'Minor Concerns';
    if (score === 3) return 'Needs Review';
    if (score === 4) return 'Concerning';
    return 'Serious Concern';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold mb-1">{name}</h1>
            <p className="text-blue-100 text-sm">{gNumber} • Section {section}</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-blue-700 hover:bg-blue-800 rounded-lg text-sm font-medium transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="max-w-2xl mx-auto px-4 py-4 space-y-3">
        <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
          <h2 className="text-sm font-semibold text-gray-600 mb-3">Your Performance</h2>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto bg-blue-50 rounded-full mb-2">
                <MessageSquare className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{submissions.length}</div>
              <div className="text-xs text-gray-500">Total Posts</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto bg-orange-50 rounded-full mb-2">
                <AlertCircle className="w-6 h-6 text-orange-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{flaggedCount}</div>
              <div className="text-xs text-gray-500">Flagged</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center w-12 h-12 mx-auto bg-red-50 rounded-full mb-2">
                <Mail className="w-6 h-6 text-red-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{emailedCount}</div>
              <div className="text-xs text-gray-500">Emails Sent</div>
            </div>
          </div>
        </div>

        {emailedCount > 0 && (
          <div className="bg-red-50 border-2 border-red-300 rounded-lg p-4">
            <div className="flex gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-bold text-red-900 text-base mb-1">Action Required</h3>
                <p className="text-sm text-red-800 font-medium mb-3">
                  You have received {emailedCount} email{emailedCount > 1 ? 's' : ''} from your instructor regarding submission concerns.
                </p>
                <button
                  onClick={() => setShowAllEmails(!showAllEmails)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium text-sm hover:bg-red-700 transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  {showAllEmails ? 'Hide All Emails' : 'View All Emails from Instructor'}
                </button>
              </div>
            </div>
          </div>
        )}

        {showAllEmails && emailedCount > 0 && (
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <Mail className="w-5 h-5 text-red-600" />
              Emails from Instructor ({emailedCount})
            </h2>
            {emails.map((email) => (
              <div key={email.id} className="bg-white border-2 border-red-300 rounded-lg overflow-hidden shadow-sm">
                <div className="bg-red-50 px-4 py-3 border-b border-red-200">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="font-bold text-gray-900 text-sm mb-1">{email.subject}</div>
                      <div className="text-xs text-gray-600">
                        Sent: {email.sentDate}
                        {email.discussionTitle && (
                          <span className="ml-2">• Discussion: {email.discussionTitle}</span>
                        )}
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-bold ${
                      email.warningNumber === 1 ? 'bg-yellow-200 text-yellow-900' :
                      email.warningNumber === 2 ? 'bg-orange-200 text-orange-900' :
                      'bg-red-200 text-red-900'
                    }`}>
                      Warning {email.warningNumber}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <div className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
                    {email.body}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {flaggedCount > 0 && emailedCount === 0 && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex gap-3">
              <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-orange-900 text-sm mb-1">Authenticity Notice</h3>
                <p className="text-sm text-orange-800">
                  Some of your submissions have been flagged for review. Please ensure all work reflects your own authentic voice and understanding.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Submissions List */}
        <div className="space-y-3 pt-2">
          <h2 className="text-lg font-bold text-gray-900">Your Submissions</h2>

          {submissions.map((submission) => (
            <div key={submission.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <div className="p-4">
                <div
                  className="cursor-pointer"
                  onClick={() => setSelectedSubmission(selectedSubmission === submission.id ? null : submission.id)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900 text-sm">{submission.discussionTitle}</h3>
                        {submission.emailSent && (
                          <Mail className="w-4 h-4 text-red-600 flex-shrink-0" />
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Calendar className="w-3 h-3" />
                        {submission.date}
                        <span className="px-2 py-0.5 bg-gray-100 rounded text-gray-600 capitalize">
                          {submission.type}
                        </span>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full border font-semibold text-sm ${getScoreColor(submission.score)}`}>
                      {submission.score}/5
                    </div>
                  </div>
                </div>

                {selectedSubmission === submission.id && (
                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <div className="mb-3">
                      <div className="text-xs font-semibold text-gray-600 mb-1">YOUR POST:</div>
                      <p className="text-sm text-gray-700 italic bg-gray-50 p-3 rounded">
                        "{submission.postExcerpt}..."
                      </p>
                    </div>

                    <div className="mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-2 h-2 rounded-full ${
                          submission.score <= 1 ? 'bg-green-500' :
                          submission.score <= 3 ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`} />
                        <div className="text-xs font-semibold text-gray-600">
                          AUTHENTICITY: {getScoreLabel(submission.score)}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">
                        {submission.score <= 1 && "Your submission demonstrates authentic voice and original thinking."}
                        {submission.score === 2 && "Your submission is acceptable but shows minor inconsistencies."}
                        {submission.score === 3 && "Your submission shows patterns that need review and discussion."}
                        {submission.score >= 4 && "Your submission shows significant concerns that require immediate attention."}
                      </p>
                    </div>

                    {submission.score >= 3 && submission.redFlags.length > 0 && (
                      <div className={`border rounded p-3 mb-3 ${
                        submission.score >= 4 ? 'bg-red-50 border-red-200' : 'bg-yellow-50 border-yellow-200'
                      }`}>
                        <div className="flex items-start gap-2 mb-2">
                          <AlertCircle className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                            submission.score >= 4 ? 'text-red-600' : 'text-yellow-600'
                          }`} />
                          <div className={`text-xs font-semibold ${
                            submission.score >= 4 ? 'text-red-900' : 'text-yellow-900'
                          }`}>
                            SPECIFIC CONCERNS:
                          </div>
                        </div>
                        <ul className="space-y-1 ml-6">
                          {submission.redFlags.map((flag, idx) => (
                            <li key={idx} className={`text-xs ${
                              submission.score >= 4 ? 'text-red-800' : 'text-yellow-800'
                            }`}>• {flag}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {submission.emailSent && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewingEmail(viewingEmail === submission.id ? null : submission.id);
                        }}
                        className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium text-sm hover:bg-red-700 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                        {viewingEmail === submission.id ? 'Hide Email' : 'View Email from Instructor'}
                      </button>
                    )}

                    {viewingEmail === submission.id && submission.emailSent && (
                      <div className="mt-3 bg-white border-2 border-red-300 rounded-lg p-4">
                        <div className="flex items-center gap-2 mb-2 pb-2 border-b border-gray-200">
                          <Mail className="w-5 h-5 text-red-600" />
                          <div>
                            <div className="font-bold text-gray-900 text-sm">{submission.emailSubject}</div>
                            <div className="text-xs text-gray-500">Sent: {submission.emailSentDate}</div>
                          </div>
                        </div>
                        <div className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
                          {submission.emailBody}
                        </div>
                      </div>
                    )}

                    {submission.score <= 1 && submission.redFlags.length === 0 && (
                      <div className="flex items-center gap-2 text-green-700 bg-green-50 px-3 py-2 rounded">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-xs font-medium">No concerns identified - Keep up the great work!</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}