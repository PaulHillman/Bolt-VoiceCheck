import { useEffect, useState } from 'react';
import { supabase, EmailTemplate } from '../lib/supabase';
import { Save, CheckCircle, AlertCircle, Activity, Mail, Download } from 'lucide-react';
import { lookupEmail, getAllEmails } from '../services/emailLookup';

export function SettingsView() {
  const [apiKey, setApiKey] = useState('');
  const [instructorName, setInstructorName] = useState('');
  const [instructorTitle, setInstructorTitle] = useState('');
  const [institution, setInstitution] = useState('');
  const [scoreThreshold, setScoreThreshold] = useState(3);
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<string>('');
  const [updatingEmails, setUpdatingEmails] = useState(false);
  const [emailUpdateResult, setEmailUpdateResult] = useState<string>('');
  const [testingResend, setTestingResend] = useState(false);
  const [resendTestResult, setResendTestResult] = useState<string>('');

  useEffect(() => {
    loadSettings();
  }, []);

  async function loadSettings() {
    try {
      const { data: apiKeyData } = await supabase
        .from('settings')
        .select('*')
        .eq('key', 'api_key')
        .maybeSingle();

      if (apiKeyData?.value?.anthropic) {
        setApiKey(apiKeyData.value.anthropic);
      }

      const { data: instructorData } = await supabase
        .from('settings')
        .select('*')
        .eq('key', 'instructor_name')
        .maybeSingle();

      if (instructorData?.value) {
        setInstructorName(instructorData.value.name || '');
        setInstructorTitle(instructorData.value.title || '');
        setInstitution(instructorData.value.institution || '');
      }

      const { data: thresholdData } = await supabase
        .from('settings')
        .select('*')
        .eq('key', 'score_threshold')
        .maybeSingle();

      if (thresholdData?.value) {
        setScoreThreshold(parseInt(thresholdData.value));
      }

      const { data: templatesData } = await supabase
        .from('email_templates')
        .select('*')
        .order('warning_level', { ascending: true });

      if (templatesData) {
        setTemplates(templatesData);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      setError('Failed to load settings');
    } finally {
      setLoading(false);
    }
  }

  async function saveSettings() {
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const { error: apiKeyError } = await supabase.from('settings').upsert(
        {
          key: 'api_key',
          value: { anthropic: apiKey },
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'key' }
      );

      if (apiKeyError) throw apiKeyError;

      const { error: instructorError } = await supabase.from('settings').upsert(
        {
          key: 'instructor_name',
          value: {
            name: instructorName,
            title: instructorTitle,
            institution: institution,
          },
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'key' }
      );

      if (instructorError) throw instructorError;

      const { error: thresholdError } = await supabase.from('settings').upsert(
        {
          key: 'score_threshold',
          value: scoreThreshold.toString(),
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'key' }
      );

      if (thresholdError) throw thresholdError;

      for (const template of templates) {
        const { error: templateError } = await supabase
          .from('email_templates')
          .update({
            subject: template.subject,
            body_template: template.body_template,
            updated_at: new Date().toISOString(),
          })
          .eq('id', template.id);

        if (templateError) throw templateError;
      }

      setSuccess('Settings saved successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(`Failed to save settings: ${err.message}`);
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  function updateTemplate(id: string, field: 'subject' | 'body_template', value: string) {
    setTemplates((prev) =>
      prev.map((t) => (t.id === id ? { ...t, [field]: value } : t))
    );
  }

  async function testAPIConnection() {
    setTesting(true);
    setTestResult('');
    setError('');

    try {
      const testApiKey = apiKey.trim();
      if (!testApiKey) {
        setError('Please enter an API key first');
        return;
      }

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-submission`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          postText: "This is a test submission to verify the API connection is working correctly.",
          apiKey: testApiKey,
          isQuestion: false
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API returned ${response.status}: ${errorText}`);
      }

      const result = await response.json();

      if (result.authenticityScore !== undefined) {
        setTestResult(`Success! API is working. Test authenticity score: ${result.authenticityScore}`);
      } else {
        setTestResult('API responded but result format is unexpected: ' + JSON.stringify(result).substring(0, 200));
      }
    } catch (err: any) {
      setError(`API Test Failed: ${err.message}`);
      console.error('API test error:', err);
    } finally {
      setTesting(false);
    }
  }

  async function updateStudentEmails() {
    setUpdatingEmails(true);
    setEmailUpdateResult('');
    setError('');

    try {
      const { data: students } = await supabase.from('students').select('*');

      if (!students || students.length === 0) {
        setEmailUpdateResult('No students found in database.');
        return;
      }

      let updatedCount = 0;
      let notFoundCount = 0;
      const notFoundNames: string[] = [];

      for (const student of students) {
        const correctEmail = lookupEmail(student.name);

        if (correctEmail && correctEmail !== student.email) {
          const { error: updateError } = await supabase
            .from('students')
            .update({ email: correctEmail })
            .eq('id', student.id);

          if (updateError) {
            console.error(`Failed to update ${student.name}:`, updateError);
          } else {
            updatedCount++;
          }
        } else if (!correctEmail) {
          notFoundCount++;
          notFoundNames.push(student.name);
        }
      }

      let resultMessage = `Updated ${updatedCount} student email(s).`;
      if (notFoundCount > 0) {
        resultMessage += ` ${notFoundCount} student(s) not found in CSV: ${notFoundNames.join(', ')}`;
      }

      setEmailUpdateResult(resultMessage);
      setSuccess('Email addresses updated successfully!');
    } catch (err: any) {
      setError(`Failed to update emails: ${err.message}`);
      console.error('Email update error:', err);
    } finally {
      setUpdatingEmails(false);
    }
  }

  async function testResendEmail() {
    setTestingResend(true);
    setResendTestResult('');
    setError('');

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`;

      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
      });

      const result = await response.json();

      if (result.success) {
        setResendTestResult(`✓ Test email sent successfully! Message ID: ${result.data?.id || 'unknown'}`);
      } else {
        setResendTestResult(`✗ Test failed: ${JSON.stringify(result, null, 2)}`);
      }
    } catch (err: any) {
      setError(`Resend Test Failed: ${err.message}`);
      console.error('Resend test error:', err);
    } finally {
      setTestingResend(false);
    }
  }

  async function downloadStudentPrompt() {
    try {
      const response = await fetch('/src/data/student-self-check-prompt.md');
      const text = await response.text();

      const blob = new Blob([text], { type: 'text/markdown' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'student-self-check-prompt.md';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(`Failed to download prompt: ${err.message}`);
      console.error('Download error:', err);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading settings...</div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-2">Configure VoiceCheck system settings</p>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">{error}</div>
        </div>
      )}

      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start space-x-2">
          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-green-800">{success}</div>
        </div>
      )}

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">API Configuration</h2>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Anthropic API Key
            </label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="sk-ant-..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <p className="text-sm text-gray-500 mt-2">
              Required for AI analysis. Get your API key from{' '}
              <a
                href="https://console.anthropic.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                console.anthropic.com
              </a>
            </p>
            <button
              onClick={testAPIConnection}
              disabled={testing || !apiKey}
              className="mt-3 flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
            >
              <Activity className="w-4 h-4" />
              <span>{testing ? 'Testing...' : 'Test API Connection'}</span>
            </button>
            {testResult && (
              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800">
                {testResult}
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Email System Testing</h2>
          <p className="text-sm text-gray-600 mb-4">
            Test the Resend email configuration (sends test email to HillmanP@gvsu.edu)
          </p>
          <button
            onClick={testResendEmail}
            disabled={testingResend}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
          >
            <Activity className="w-4 h-4" />
            <span>{testingResend ? 'Testing...' : 'Test Resend Email'}</span>
          </button>
          {resendTestResult && (
            <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-800 font-mono whitespace-pre-wrap">
              {resendTestResult}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Student Email Management</h2>
          <p className="text-sm text-gray-600 mb-4">
            Update all student email addresses from the roster CSV file
          </p>
          <button
            onClick={updateStudentEmails}
            disabled={updatingEmails}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-sm"
          >
            <Mail className="w-4 h-4" />
            <span>{updatingEmails ? 'Updating...' : 'Update All Email Addresses'}</span>
          </button>
          {emailUpdateResult && (
            <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-800">
              {emailUpdateResult}
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Student Resources</h2>
          <p className="text-sm text-gray-600 mb-4">
            Download the self-check prompt that students can use to review their work before submitting to Packback
          </p>
          <button
            onClick={downloadStudentPrompt}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
          >
            <Download className="w-4 h-4" />
            <span>Download Student Self-Check Prompt</span>
          </button>
          <p className="text-xs text-gray-500 mt-3">
            This prompt helps students check their writing authenticity using ChatGPT or Claude before submission
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Instructor Information</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Instructor Name
              </label>
              <input
                type="text"
                value={instructorName}
                onChange={(e) => setInstructorName(e.target.value)}
                placeholder="Dr. Jane Smith"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
              <input
                type="text"
                value={instructorTitle}
                onChange={(e) => setInstructorTitle(e.target.value)}
                placeholder="Assistant Professor"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Institution
              </label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                placeholder="University Name"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Analysis Settings</h2>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Flagging Threshold (Authenticity Score)
            </label>
            <select
              value={scoreThreshold}
              onChange={(e) => setScoreThreshold(parseInt(e.target.value))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value={2}>2 - Likely Authentic (Conservative)</option>
              <option value={3}>3 - Suspicious (Recommended)</option>
              <option value={4}>4 - Likely AI-Generated (Strict)</option>
            </select>
            <p className="text-sm text-gray-500 mt-2">
              Submissions with scores at or above this threshold will be flagged for review
            </p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Email Templates</h2>
          <p className="text-sm text-gray-600 mb-6">
            Customize email templates for different warning levels. Use placeholders like{' '}
            <code className="bg-gray-100 px-1 py-0.5 rounded">{'{{student_name}}'}</code>,{' '}
            <code className="bg-gray-100 px-1 py-0.5 rounded">{'{{post_date}}'}</code>,{' '}
            <code className="bg-gray-100 px-1 py-0.5 rounded">{'{{discussion_title}}'}</code>,{' '}
            <code className="bg-gray-100 px-1 py-0.5 rounded">{'{{explanation}}'}</code>,{' '}
            <code className="bg-gray-100 px-1 py-0.5 rounded">{'{{red_flags}}'}</code>
          </p>

          <div className="space-y-6">
            {templates.map((template) => (
              <div key={template.id} className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-gray-900 mb-3">
                  Warning Level {template.warning_level}
                  {template.warning_level === 1 && ' - First Warning'}
                  {template.warning_level === 2 && ' - Second Warning'}
                  {template.warning_level === 3 && ' - Third Warning (Meeting Required)'}
                  {template.warning_level === 4 && ' - Academic Integrity Violation'}
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={template.subject}
                      onChange={(e) => updateTemplate(template.id, 'subject', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Body Template
                    </label>
                    <textarea
                      value={template.body_template}
                      onChange={(e) =>
                        updateTemplate(template.id, 'body_template', e.target.value)
                      }
                      rows={8}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-xs"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={saveSettings}
            disabled={saving}
            className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            <Save className="w-5 h-5" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
