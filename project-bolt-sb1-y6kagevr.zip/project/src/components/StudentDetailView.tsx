import { useEffect, useState } from 'react';
import {
  supabase,
  Student,
  Submission,
  AnalysisResult,
  Warning,
  Discussion,
} from '../lib/supabase';
import { ArrowLeft, AlertCircle, Calendar, TrendingUp, Mail, CreditCard as Edit2, Send, Eye } from 'lucide-react';
import { analyzeAndSaveSubmission } from '../services/aiAnalysis';

interface StudentDetailViewProps {
  studentId: string;
  onBack: () => void;
  viewMode?: 'admin' | 'student';
  onGenerateEmail?: (studentId: string, submissionId: string) => void;
}

interface SubmissionWithAnalysis {
  submission: Submission;
  analysis: AnalysisResult | null;
  discussion: Discussion | null;
}

interface EmailLog {
  id: string;
  subject: string;
  body: string;
  sentAt: string;
  warningNumber: number;
  discussionTitle?: string;
}

export function StudentDetailView({
  studentId,
  onBack,
  viewMode = 'admin',
  onGenerateEmail,
}: StudentDetailViewProps) {
  const [student, setStudent] = useState<Student | null>(null);
  const [submissions, setSubmissions] = useState<SubmissionWithAnalysis[]>([]);
  const [warnings, setWarnings] = useState<Warning[]>([]);
  const [emails, setEmails] = useState<EmailLog[]>([]);
  const [logins, setLogins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [expandedEmailId, setExpandedEmailId] = useState<string | null>(null);
  const [editingScoreId, setEditingScoreId] = useState<string | null>(null);
  const [editedScore, setEditedScore] = useState<number>(0);
  const [generatingEmail, setGeneratingEmail] = useState<string | null>(null);

  useEffect(() => {
    if (studentId) {
      loadStudentData();
    }
  }, [studentId]);

  async function loadStudentData() {
    try {
      if (!studentId) {
        console.error('No studentId provided to StudentDetailView');
        return;
      }

      const { data: studentData, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (studentError) throw studentError;
      setStudent(studentData);

      const { data: submissionsData, error: submissionsError } = await supabase
        .from('submissions')
        .select('*')
        .eq('student_id', studentId)
        .order('created_at', { ascending: false });

      if (submissionsError) throw submissionsError;

      const submissionsWithData = await Promise.all(
        (submissionsData || []).map(async (submission) => {
          const { data: analysis } = await supabase
            .from('analysis_results')
            .select('*')
            .eq('submission_id', submission.id)
            .maybeSingle();

          const { data: discussion } = await supabase
            .from('discussions')
            .select('*')
            .eq('id', submission.discussion_id)
            .maybeSingle();

          return {
            submission,
            analysis: analysis || null,
            discussion: discussion || null,
          };
        })
      );

      setSubmissions(submissionsWithData);

      const { data: warningsData, error: warningsError } = await supabase
        .from('warnings')
        .select('*')
        .eq('student_id', studentId)
        .order('sent_date', { ascending: false });

      if (warningsError) throw warningsError;
      setWarnings(warningsData || []);

      const { data: emailsData, error: emailsError } = await supabase
        .from('email_logs')
        .select(`
          id,
          subject,
          body,
          sent_at,
          warning_number,
          submissions (
            discussions (
              title
            )
          )
        `)
        .eq('student_id', studentId)
        .order('sent_at', { ascending: false });

      if (emailsError) throw emailsError;

      const formattedEmails: EmailLog[] = (emailsData || []).map((email: any) => ({
        id: email.id,
        subject: email.subject,
        body: email.body,
        sentAt: new Date(email.sent_at).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: 'numeric',
          minute: '2-digit'
        }),
        warningNumber: email.warning_number,
        discussionTitle: email.submissions?.discussions?.title
      }));

      setEmails(formattedEmails);

      const { data: loginsData, error: loginsError } = await supabase
        .from('student_logins')
        .select('*')
        .eq('g_number', studentData.g_number)
        .order('logged_in_at', { ascending: false });

      if (loginsError) {
        console.error('Error loading login data:', loginsError);
      } else {
        setLogins(loginsData || []);
      }
    } catch (error) {
      console.error('Error loading student data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function analyzeSubmission(submissionId: string, postText: string) {
    setAnalyzing(true);
    try {
      const { data: settings } = await supabase
        .from('settings')
        .select('value')
        .eq('key', 'api_key')
        .maybeSingle();

      const apiKey = settings?.value?.anthropic || '';
      if (!apiKey) {
        alert('Please configure your Anthropic API key in settings first.');
        return;
      }

      await analyzeAndSaveSubmission(submissionId, postText, apiKey);
      await loadStudentData();
    } catch (error) {
      console.error('Error analyzing submission:', error);
      alert('Failed to analyze submission. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  }

  async function handleEditScore(analysisId: string, currentScore: number) {
    setEditingScoreId(analysisId);
    setEditedScore(currentScore);
  }

  async function handleSaveScore(analysisId: string) {
    try {
      const { error } = await supabase
        .from('analysis_results')
        .update({ authenticity_score: editedScore })
        .eq('id', analysisId);

      if (error) throw error;

      await loadStudentData();
      setEditingScoreId(null);
    } catch (error) {
      console.error('Error updating score:', error);
      alert('Failed to update score. Please try again.');
    }
  }

  async function handleGenerateEmail(submissionId: string) {
    if (onGenerateEmail) {
      setGeneratingEmail(submissionId);
      try {
        await onGenerateEmail(studentId, submissionId);
      } catch (error) {
        console.error('Error generating email:', error);
        alert('Failed to generate email. Please try again.');
      } finally {
        setGeneratingEmail(null);
      }
    }
  }


  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading student details...</div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Student not found</div>
      </div>
    );
  }

  const flaggedSubmissions = submissions.filter(
    (s) => s.analysis && s.analysis.authenticity_score >= 3
  );

  const averageScore =
    submissions.length > 0
      ? submissions
          .filter((s) => s.analysis)
          .reduce((sum, s) => sum + (s.analysis?.authenticity_score || 0), 0) /
        submissions.filter((s) => s.analysis).length
      : 0;

  function getScoreColor(score: number) {
    if (score <= 2) return 'text-green-600 bg-green-50 border-green-200';
    if (score === 3) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={onBack}
        className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Dashboard</span>
      </button>

      <div className="bg-white rounded-lg shadow-lg p-8 mb-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{student.name}</h1>
            <p className="text-gray-600 mt-1">{student.email}</p>
            {student.section && (
              <p className="text-sm text-gray-500 mt-1">Section: {student.section}</p>
            )}
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500">Total Warnings</div>
            <div className="text-4xl font-bold text-red-600">{warnings.length}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="text-sm text-blue-600 font-medium">Total Submissions</div>
            <div className="text-2xl font-bold text-blue-900">{submissions.length}</div>
          </div>
          <div className="bg-red-50 rounded-lg p-4 border border-red-200">
            <div className="text-sm text-red-600 font-medium">Flagged Submissions</div>
            <div className="text-2xl font-bold text-red-900">{flaggedSubmissions.length}</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="text-sm text-purple-600 font-medium">Average Score</div>
            <div className="text-2xl font-bold text-purple-900">
              {averageScore.toFixed(1)}/5
            </div>
          </div>
          <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
            <div className="text-sm text-yellow-600 font-medium">First Flagged</div>
            <div className="text-sm font-bold text-yellow-900">
              {student.first_flagged_date
                ? new Date(student.first_flagged_date).toLocaleDateString()
                : 'Never'}
            </div>
          </div>
          <div className="bg-teal-50 rounded-lg p-4 border border-teal-200">
            <div className="text-sm text-teal-600 font-medium">Portal Logins</div>
            <div className="text-2xl font-bold text-teal-900">{logins.length}</div>
            <div className="text-xs text-teal-700 mt-1">
              {logins.length > 0 ? (
                <>Last: {new Date(logins[0].logged_in_at).toLocaleDateString()}</>
              ) : (
                'Never'
              )}
            </div>
          </div>
        </div>
      </div>

      {logins.length > 0 && viewMode === 'admin' && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Eye className="w-5 h-5 text-teal-600" />
            <h2 className="text-xl font-bold text-gray-900">Portal Login History</h2>
          </div>
          <div className="space-y-2">
            {logins.map((login, index) => (
              <div
                key={index}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  index === 0
                    ? 'bg-teal-50 border-teal-300 border-2'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    index === 0 ? 'bg-teal-500' : 'bg-gray-400'
                  }`}></div>
                  <div>
                    <div className={`text-sm font-medium ${
                      index === 0 ? 'text-teal-900' : 'text-gray-900'
                    }`}>
                      {new Date(login.logged_in_at).toLocaleDateString('en-US', {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </div>
                    <div className={`text-xs ${
                      index === 0 ? 'text-teal-700' : 'text-gray-600'
                    }`}>
                      {new Date(login.logged_in_at).toLocaleTimeString('en-US', {
                        hour: 'numeric',
                        minute: '2-digit',
                        hour12: true
                      })}
                    </div>
                  </div>
                </div>
                {index === 0 && (
                  <span className="px-2 py-1 bg-teal-200 text-teal-900 text-xs font-bold rounded">
                    Latest
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {emails.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Mail className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-bold text-gray-900">Email History ({emails.length})</h2>
          </div>
          <div className="space-y-3">
            {emails.map((email) => (
              <div key={email.id} className="border-2 border-red-200 rounded-lg overflow-hidden">
                <div
                  className="bg-red-50 px-4 py-3 cursor-pointer hover:bg-red-100 transition-colors"
                  onClick={() => setExpandedEmailId(expandedEmailId === email.id ? null : email.id)}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="font-bold text-gray-900 text-sm mb-1">{email.subject}</div>
                      <div className="text-xs text-gray-600">
                        Sent: {email.sentAt}
                        {email.discussionTitle && (
                          <span className="ml-2">• Discussion: {email.discussionTitle}</span>
                        )}
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap ${
                      email.warningNumber === 1 ? 'bg-yellow-200 text-yellow-900' :
                      email.warningNumber === 2 ? 'bg-orange-200 text-orange-900' :
                      'bg-red-200 text-red-900'
                    }`}>
                      Warning {email.warningNumber}
                    </span>
                  </div>
                </div>
                {expandedEmailId === email.id && (
                  <div className="p-4 bg-white border-t border-red-200">
                    <div className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
                      {email.body}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {warnings.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Calendar className="w-5 h-5 text-red-600" />
            <h2 className="text-xl font-bold text-gray-900">Warning History (Legacy)</h2>
          </div>
          <div className="space-y-3">
            {warnings.map((warning) => (
              <div key={warning.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                        Warning #{warning.warning_number}
                      </span>
                      <span className="text-sm text-gray-500">
                        {new Date(warning.sent_date).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-2 line-clamp-2">
                      {warning.email_content.substring(0, 200)}...
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center space-x-2 mb-6">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">All Submissions</h2>
        </div>

        <div className="space-y-6">
          {submissions.map((item) => (
            <div
              key={item.submission.id}
              className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">
                    {item.discussion?.title || 'Discussion'}
                  </h3>
                  <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                    <span>
                      Posted:{' '}
                      {item.submission.post_timestamp
                        ? new Date(item.submission.post_timestamp).toLocaleDateString()
                        : 'Unknown'}
                    </span>
                    {item.submission.response_score && (
                      <span>Packback Score: {item.submission.response_score}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {item.analysis ? (
                    <>
                      {editingScoreId === item.analysis.id ? (
                        <div className="flex items-center space-x-2">
                          <input
                            type="number"
                            min="0"
                            max="5"
                            value={editedScore}
                            onChange={(e) => setEditedScore(parseInt(e.target.value))}
                            className="w-16 px-2 py-1 border border-gray-300 rounded text-center"
                          />
                          <button
                            onClick={() => handleSaveScore(item.analysis!.id)}
                            className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingScoreId(null)}
                            className="px-3 py-1 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 text-sm"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <div
                            className={`px-4 py-2 rounded-lg border font-semibold ${getScoreColor(
                              item.analysis.authenticity_score
                            )}`}
                          >
                            Score: {item.analysis.authenticity_score}/5
                          </div>
                          {viewMode === 'admin' && (
                            <button
                              onClick={() => handleEditScore(item.analysis!.id, item.analysis!.authenticity_score)}
                              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
                              title="Edit Score"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      )}
                      {viewMode === 'admin' && item.analysis.authenticity_score >= 3 && (
                        <button
                          onClick={() => handleGenerateEmail(item.submission.id)}
                          disabled={generatingEmail === item.submission.id}
                          className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:bg-gray-300 transition-colors text-sm"
                        >
                          <Send className="w-4 h-4" />
                          <span>{generatingEmail === item.submission.id ? 'Generating...' : 'Generate Email'}</span>
                        </button>
                      )}
                    </>
                  ) : (
                    viewMode === 'admin' && (
                      <button
                        onClick={() =>
                          analyzeSubmission(item.submission.id, item.submission.post_text)
                        }
                        disabled={analyzing}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 transition-colors text-sm"
                      >
                        {analyzing ? 'Analyzing...' : 'Analyze'}
                      </button>
                    )
                  )}
                </div>
              </div>

              {item.analysis && (
                <div className="mb-4">
                  <div className="mb-3">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Red Flags:</h4>
                    <div className="flex flex-wrap gap-2">
                      {item.analysis.red_flags.map((flag, idx) => (
                        <span
                          key={idx}
                          className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800"
                        >
                          <AlertCircle className="w-3 h-3 mr-1" />
                          {flag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-gray-700 mb-2">Explanation:</h4>
                    <p className="text-sm text-gray-700 whitespace-pre-wrap">
                      {item.analysis.explanation}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Submission Text:</h4>
                <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-700 whitespace-pre-wrap max-h-64 overflow-y-auto">
                  {item.submission.post_text}
                </div>
              </div>
            </div>
          ))}

          {submissions.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No submissions found for this student.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
