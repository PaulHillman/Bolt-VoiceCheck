import { useState } from 'react';
import { LogIn, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface LoginSplashProps {
  onAdminLogin: () => void;
  onStudentLogin: (gNumber: string) => void;
  onAnalystLogin: () => void;
}

export function LoginSplash({ onAdminLogin, onStudentLogin, onAnalystLogin }: LoginSplashProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPassword = password.trim();

    if (!trimmedEmail) {
      setError('Please enter your email address');
      return;
    }

    if (!trimmedPassword) {
      setError('Please enter your password or G-number');
      return;
    }

    setIsLoading(true);
    try {
      // Check if password is a G-number (student login)
      if (trimmedPassword.toUpperCase().match(/^G\d{8}$/)) {
        onStudentLogin(trimmedPassword.toUpperCase());
        return;
      }

      // Try Supabase authentication for admin/analyst users
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: trimmedEmail,
        password: trimmedPassword,
      });

      if (signInError) {
        setError('Invalid credentials. Please check your email and password/G-number.');
        setIsLoading(false);
        return;
      }

      if (data.user) {
        // Get user profile to determine role
        const { data: profile, error: profileError } = await supabase
          .from('user_profiles')
          .select('role, allowed_features')
          .eq('email', trimmedEmail)
          .maybeSingle();

        if (profileError || !profile) {
          setError('User profile not found.');
          setIsLoading(false);
          return;
        }

        // Route based on role
        if (profile.role === 'admin') {
          onAdminLogin();
        } else if (profile.role === 'analyst') {
          onAnalystLogin();
        } else {
          setError('Unknown user role.');
          setIsLoading(false);
        }
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <img
            src="/VoiceCheckLogo_Writing.png"
            alt="VoiceCheck - Authentic Writing Detection"
            className="w-full max-w-md mx-auto mb-6"
            style={{ maxHeight: '120px', objectFit: 'contain' }}
          />
        </div>

        <div className="bg-slate-800 rounded-2xl shadow-2xl border border-slate-700 overflow-hidden">
          <div className="bg-gradient-to-r from-teal-500 via-cyan-500 to-teal-400 px-8 py-8 text-center">
            <h1 className="text-2xl font-bold text-slate-900 mb-1">
              VoiceCheck: Writing Detection
            </h1>
            <p className="text-slate-800 text-sm">
              Sign in to access your account
            </p>
          </div>

          <div className="px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="mb-6 text-center">
                <h2 className="text-xl font-bold bg-gradient-to-r from-teal-400 via-cyan-400 to-teal-300 bg-clip-text text-transparent mb-2">Sign In</h2>
                <p className="text-slate-400 text-sm">
                  Enter your credentials to continue
                </p>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-teal-400 mb-2">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError('');
                  }}
                  placeholder="your.email@gvsu.edu"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 text-white placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all"
                  disabled={isLoading}
                  autoFocus
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-semibold text-teal-400 mb-2">
                  Password / G#
                </label>
                <input
                  id="password"
                  type="text"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError('');
                  }}
                  placeholder="Password or G12345678"
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 text-white placeholder-slate-500 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all"
                  disabled={isLoading}
                />
                <p className="mt-2 text-xs text-slate-500">
                  Students: Enter your G-number (e.g., G12345678)
                </p>
              </div>

              {error && (
                <div className="flex items-start gap-3 p-4 bg-red-900/30 border border-red-700 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-300 font-medium">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-teal-500 via-cyan-500 to-teal-400 text-slate-900 py-3 px-6 rounded-lg font-semibold hover:from-teal-600 hover:via-cyan-600 hover:to-teal-500 focus:ring-4 focus:ring-teal-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
              >
                <LogIn className="w-5 h-5" />
                {isLoading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
