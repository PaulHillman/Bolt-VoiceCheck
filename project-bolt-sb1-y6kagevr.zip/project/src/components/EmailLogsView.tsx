import { useEffect, useState } from 'react';
import { supabase, EmailLog, Student } from '../lib/supabase';
import { Mail, Calendar, User, ArrowUpDown, Search } from 'lucide-react';

interface EmailLogWithStudent extends EmailLog {
  student?: Student;
}

export function EmailLogsView() {
  const [logs, setLogs] = useState<EmailLogWithStudent[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLog, setSelectedLog] = useState<EmailLogWithStudent | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'student' | 'warning'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    loadEmailLogs();
  }, []);

  async function loadEmailLogs() {
    try {
      const { data: logsData, error: logsError } = await supabase
        .from('email_logs')
        .select('*')
        .order('sent_at', { ascending: false });

      if (logsError) throw logsError;

      const logsWithStudents = await Promise.all(
        (logsData || []).map(async (log) => {
          const { data: student } = await supabase
            .from('students')
            .select('*')
            .eq('id', log.student_id)
            .maybeSingle();

          return {
            ...log,
            student: student || undefined,
          };
        })
      );

      setLogs(logsWithStudents);
    } catch (error) {
      console.error('Error loading email logs:', error);
    } finally {
      setLoading(false);
    }
  }

  function getFilteredAndSortedLogs() {
    let filtered = logs;

    if (searchTerm) {
      filtered = logs.filter(
        (log) =>
          log.student?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.student?.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.subject.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered.sort((a, b) => {
      let comparison = 0;

      if (sortBy === 'date') {
        comparison = new Date(a.sent_at).getTime() - new Date(b.sent_at).getTime();
      } else if (sortBy === 'student') {
        const nameA = a.student?.name || '';
        const nameB = b.student?.name || '';
        comparison = nameA.localeCompare(nameB);
      } else if (sortBy === 'warning') {
        comparison = a.warning_number - b.warning_number;
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }

  function toggleSort(newSortBy: 'date' | 'student' | 'warning') {
    if (sortBy === newSortBy) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(newSortBy);
      setSortOrder('desc');
    }
  }

  function getWarningBadgeColor(warningNumber: number) {
    if (warningNumber === 1) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    if (warningNumber === 2) return 'bg-orange-100 text-orange-800 border-orange-200';
    return 'bg-red-100 text-red-800 border-red-200';
  }

  const filteredLogs = getFilteredAndSortedLogs();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading email logs...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Email Log History</h1>
        <p className="text-gray-600 mt-2">View all emails sent through the system</p>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by student name, email, or subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Email Log</h2>
              <p className="text-sm text-gray-500 mt-1">{filteredLogs.length} email(s)</p>
            </div>

            <div className="p-4 border-b border-gray-200 bg-gray-50">
              <div className="flex space-x-2">
                <button
                  onClick={() => toggleSort('date')}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                    sortBy === 'date'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Calendar className="w-3 h-3" />
                  <span>Date</span>
                  {sortBy === 'date' && <ArrowUpDown className="w-3 h-3" />}
                </button>
                <button
                  onClick={() => toggleSort('student')}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                    sortBy === 'student'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <User className="w-3 h-3" />
                  <span>Student</span>
                  {sortBy === 'student' && <ArrowUpDown className="w-3 h-3" />}
                </button>
                <button
                  onClick={() => toggleSort('warning')}
                  className={`flex items-center space-x-1 px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                    sortBy === 'warning'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Mail className="w-3 h-3" />
                  <span>Warning</span>
                  {sortBy === 'warning' && <ArrowUpDown className="w-3 h-3" />}
                </button>
              </div>
            </div>

            <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
              {filteredLogs.length === 0 && (
                <div className="p-6 text-center text-gray-500 text-sm">
                  No email logs found.
                </div>
              )}
              {filteredLogs.map((log) => (
                <button
                  key={log.id}
                  onClick={() => setSelectedLog(log)}
                  className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                    selectedLog?.id === log.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">
                        {log.student?.name || 'Unknown Student'}
                      </div>
                      <div className="text-sm text-gray-500">{log.recipient_email}</div>
                    </div>
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getWarningBadgeColor(
                        log.warning_number
                      )}`}
                    >
                      Warning #{log.warning_number}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {new Date(log.sent_at).toLocaleString()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          {selectedLog ? (
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">
                      {selectedLog.student?.name || 'Unknown Student'}
                    </h2>
                    <p className="text-sm text-gray-500 mt-1">
                      {selectedLog.recipient_email}
                    </p>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                      <span className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(selectedLog.sent_at).toLocaleString()}</span>
                      </span>
                      {selectedLog.cc_emails && selectedLog.cc_emails.length > 0 && (
                        <span className="text-xs">
                          CC: {selectedLog.cc_emails.join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                  <span
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getWarningBadgeColor(
                      selectedLog.warning_number
                    )}`}
                  >
                    Warning #{selectedLog.warning_number}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg text-gray-900">
                    {selectedLog.subject}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Body
                  </label>
                  <div className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-lg text-gray-700 whitespace-pre-wrap font-mono text-sm max-h-[500px] overflow-y-auto">
                    {selectedLog.body}
                  </div>
                </div>

                {selectedLog.resend_message_id && (
                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="text-xs text-blue-800">
                      <strong>Resend Message ID:</strong> {selectedLog.resend_message_id}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-12 text-center">
              <Mail className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Email Selected</h3>
              <p className="text-gray-500">
                Select an email from the list to view its details.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
