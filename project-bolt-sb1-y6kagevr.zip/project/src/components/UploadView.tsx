import { useState, useRef } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, File, Sparkles, AlertTriangle, MessageCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { analyzeSubmission } from '../services/aiAnalysis';
import { lookupEmail } from '../services/emailLookup';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';

interface ParsedSubmission {
  studentName: string;
  studentEmail: string;
  section: string;
  discussionTitle: string;
  discussionDate: string;
  postText: string;
  postTimestamp: string;
  responseScore: number;
  authenticityScore?: number;
  redFlags?: string[];
  explanation?: string;
  analyzing?: boolean;
  analysisError?: string;
  isQuestion?: boolean;
}

export function UploadView() {
  const [textInput, setTextInput] = useState('');
  const [parsedData, setParsedData] = useState<ParsedSubmission[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [currentAnalysisIndex, setCurrentAnalysisIndex] = useState(-1);
  const [totalAnalysis, setTotalAnalysis] = useState(0);
  const [startTime, setStartTime] = useState<number>(0);
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState<string>('');
  const [pasteTextExpanded, setPasteTextExpanded] = useState(false);

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (files) {
      setUploadedFiles(Array.from(files));
      setError('');
      setSuccess('');
    }
  }

  function handleFileDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files) {
      setUploadedFiles(Array.from(files));
      setError('');
      setSuccess('');
    }
  }

  function handleDragOver(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
  }

  async function extractTextFromPDF(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let text = '';

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();

        // Preserve line structure by tracking y positions
        let lastY = -1;
        let pageText = '';

        for (const item of content.items as any[]) {
          const currentY = item.transform[5];

          // If we've moved to a new line (different y position)
          if (lastY !== -1 && Math.abs(currentY - lastY) > 2) {
            pageText += '\n';
          }

          pageText += item.str + ' ';
          lastY = currentY;
        }

        text += pageText + '\n';
      }

      return text;
    } catch (err) {
      console.error('PDF extraction error:', err);
      throw new Error(`Failed to extract text from ${file.name}: ${err}`);
    }
  }

  async function processFiles() {
    setError('');
    setParsedData([]);
    setLoading(true);

    try {
      let allText = '';
      const errors: string[] = [];

      for (const file of uploadedFiles) {
        try {
          if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
            const pdfText = await extractTextFromPDF(file);
            allText += pdfText + '\n\n';
          } else {
            const text = await file.text();
            allText += text + '\n\n';
          }
        } catch (fileErr: any) {
          errors.push(`${file.name}: ${fileErr.message}`);
          console.error(`Error processing ${file.name}:`, fileErr);
        }
      }

      if (errors.length > 0 && allText.trim() === '') {
        setError(`Failed to process files:\n${errors.join('\n')}`);
        return;
      }

      if (allText.trim() === '') {
        setError('No text content found in uploaded files.');
        return;
      }

      await parseText(allText);

      if (errors.length > 0) {
        const currentSuccess = success;
        setSuccess(`${currentSuccess}${currentSuccess ? ' ' : ''}Some files had errors: ${errors.join(', ')}`);
      }

      setUploadedFiles([]);
    } catch (err: any) {
      setError(`Error processing files: ${err.message || err}`);
      console.error('processFiles error:', err);
    } finally {
      setLoading(false);
    }
  }

  async function parseSubmissions() {
    setError('');
    setParsedData([]);
    setLoading(true);
    await parseText(textInput);
    setLoading(false);
  }

  async function parseText(text: string) {
    const submissions: ParsedSubmission[] = [];

    try {
      const askedByPattern = /(?:Asked by|Response shared by)\s+([^\n]+)\s+Student\s+Section:\s+([^\n]+)/g;
      const timestampPattern = /(\d{1,2}:\d{2}\s+(?:AM|PM),\s+\d{1,2}\/\d{1,2}\/\d{4})\s+[⚙🔔]?(\d+)/g;

      const matches = [...text.matchAll(askedByPattern)];

      if (matches.length === 0) {
        const lines = text.split('\n').filter((line) => line.trim());
        let currentSubmission: Partial<ParsedSubmission> = {};
        let collectingPostText = false;
        let postTextLines: string[] = [];

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();

          if (line.startsWith('Student:')) {
            if (currentSubmission.studentName && currentSubmission.postText) {
              currentSubmission.postText = postTextLines.join('\n').trim();
              submissions.push(currentSubmission as ParsedSubmission);
            }
            currentSubmission = {};
            postTextLines = [];
            collectingPostText = false;
            currentSubmission.studentName = line.replace('Student:', '').trim();
          } else if (line.startsWith('Email:')) {
            currentSubmission.studentEmail = line.replace('Email:', '').trim();
          } else if (line.startsWith('Section:')) {
            currentSubmission.section = line.replace('Section:', '').trim();
          } else if (line.startsWith('Discussion:')) {
            currentSubmission.discussionTitle = line.replace('Discussion:', '').trim();
          } else if (line.startsWith('Date:')) {
            currentSubmission.discussionDate = line.replace('Date:', '').trim();
          } else if (line.startsWith('Posted:')) {
            currentSubmission.postTimestamp = line.replace('Posted:', '').trim();
          } else if (line.startsWith('Score:')) {
            currentSubmission.responseScore = parseInt(line.replace('Score:', '').trim());
          } else if (line.startsWith('Post:')) {
            collectingPostText = true;
            postTextLines.push(line.replace('Post:', '').trim());
          } else if (collectingPostText) {
            postTextLines.push(line);
          }
        }

        if (currentSubmission.studentName && postTextLines.length > 0) {
          currentSubmission.postText = postTextLines.join('\n').trim();
          submissions.push(currentSubmission as ParsedSubmission);
        }
      } else {
        for (let i = 0; i < matches.length; i++) {
          const match = matches[i];
          const studentName = match[1].trim();
          const section = match[2].trim();

          const startIndex = match.index!;
          const endIndex = i < matches.length - 1 ? matches[i + 1].index! : text.length;
          const submissionText = text.substring(startIndex, endIndex);

          const timestampMatch = submissionText.match(/(\d{1,2}:\d{2}\s+(?:AM|PM),\s+\d{1,2}\/\d{1,2}\/\d{4})\s+[⚙🔔]?(\d+)/);
          const postTimestamp = timestampMatch ? timestampMatch[1] : '';
          const responseScore = timestampMatch ? parseInt(timestampMatch[2]) : 0;

          const titleMatch = submissionText.match(/(?:Question|Response)\s*\n\s*(?:Reply to Question:\s*)?(.*?)(?:\n|$)/s);
          let discussionTitle = titleMatch ? titleMatch[1].trim() : 'Packback Discussion';

          // Remove UI elements and invalid characters from the title
          discussionTitle = discussionTitle
            .replace(/[⚙🔔📝▾]/g, '')
            .replace(/\s*Options\s*/g, '')
            .replace(/\s*Back to\s+.*/g, '')
            .replace(/\s*View\s+all.*/g, '')
            .replace(/\s*Add Response.*/g, '')
            .replace(/\s*Counter\s+Points.*/g, '')
            .replace(/\s*Supporting\s+Points.*/g, '')
            .trim();

          // If the title is too short or looks like UI text, try to find the actual question in the post text
          if (discussionTitle.length < 10 || discussionTitle.includes('Options')) {
            // Look for question patterns in the post text
            const questionMatch = submissionText.match(/(?:If|Should|Would|Could|Can|Does|Do|Is|Are|Was|Were|Why|What|How|When|Where|Who)[^?]*\?/);
            if (questionMatch) {
              discussionTitle = questionMatch[0].trim();
            }
          }

          if (discussionTitle.length > 120) {
            discussionTitle = discussionTitle.substring(0, 120) + '...';
          }

          const lines = submissionText.split('\n');
          let postTextLines: string[] = [];
          let foundStart = false;
          let skipNextLines = 0;

          for (let j = 0; j < lines.length; j++) {
            const line = lines[j].trim();

            if (skipNextLines > 0) {
              skipNextLines--;
              continue;
            }

            // Skip metadata and UI elements
            if (line.includes('Add Response') ||
                line.includes('Options') ||
                line.includes('Counter') ||
                line.includes('Supporting') ||
                line.includes('Expand All') ||
                line.includes('Back to Discussion') ||
                line.includes('Back to Full') ||
                line.includes('View all responses') ||
                line.includes('Help Center') ||
                line.includes('Site Status') ||
                line.includes('Privacy Policy') ||
                line.includes('Terms of Use') ||
                line.includes('Packback Inc') ||
                line.includes('© Packback') ||
                line.includes('Response Details') ||
                line.includes('This response received') ||
                line.includes('You\'re currently viewing') ||
                line.match(/^\d{1,2}:\d{2}\s+(?:AM|PM)/) ||
                line.match(/^Section:\s+\d+:\d+/) ||
                line.match(/^[⚙🔔📝▾]/)) {
              continue;
            }

            // Start collecting after we see the student name
            if (!foundStart && line.length > 30) {
              foundStart = true;
            }

            if (foundStart && line.length > 0) {
              postTextLines.push(line);
            }
          }

          const postText = postTextLines.join(' ').trim();

          if (postText.length > 40) {
            const correctEmail = lookupEmail(studentName) || `${studentName.toLowerCase().replace(/\s+/g, '.')}@university.edu`;

            submissions.push({
              studentName,
              studentEmail: correctEmail,
              section,
              discussionTitle,
              discussionDate: postTimestamp.split(',')[1]?.trim() || '',
              postText,
              postTimestamp,
              responseScore,
            });
          }
        }
      }

      if (submissions.length === 0) {
        setError('No valid submissions found. The file may not contain Packback discussion data in a recognized format.');
      } else {
        await checkForDuplicates(submissions);
      }
    } catch (err: any) {
      setError(`Error parsing submissions: ${err.message || err}`);
      console.error('parseText error:', err);
    }
  }

  async function analyzeSubmissions() {
    const { data: settings } = await supabase
      .from('settings')
      .select('value')
      .eq('key', 'api_key')
      .maybeSingle();

    const apiKey = settings?.value?.anthropic;
    if (!apiKey) {
      setError('No API key configured. Please add your Claude API key in Settings before analyzing submissions.');
      return;
    }

    setLoading(true);
    setError('');
    setStartTime(Date.now());
    setTotalAnalysis(parsedData.length);
    setCurrentAnalysisIndex(0);

    try {
      const updatedSubmissions = [...parsedData];

      for (let i = 0; i < updatedSubmissions.length; i++) {
        setCurrentAnalysisIndex(i + 1);
        updatedSubmissions[i].analyzing = true;
        updatedSubmissions[i].analysisError = undefined;
        setParsedData([...updatedSubmissions]);

        try {
          const itemStartTime = Date.now();
          const analysis = await analyzeSubmission(
            updatedSubmissions[i].postText,
            apiKey,
            updatedSubmissions[i].isQuestion || false
          );
          const itemDuration = Date.now() - itemStartTime;

          const averageTimePerItem = (Date.now() - startTime) / (i + 1);
          const remainingItems = updatedSubmissions.length - (i + 1);
          const estimatedMs = averageTimePerItem * remainingItems;

          if (remainingItems > 0) {
            const minutes = Math.floor(estimatedMs / 60000);
            const seconds = Math.floor((estimatedMs % 60000) / 1000);
            setEstimatedTimeRemaining(
              minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`
            );
          }

          updatedSubmissions[i].authenticityScore = analysis.authenticityScore;
          updatedSubmissions[i].redFlags = analysis.redFlags;
          updatedSubmissions[i].explanation = analysis.explanation;
          updatedSubmissions[i].analyzing = false;
        } catch (err: any) {
          updatedSubmissions[i].analyzing = false;
          updatedSubmissions[i].analysisError = err.message;
          console.error(`Error analyzing submission ${i}:`, err);
        }

        setParsedData([...updatedSubmissions]);
      }

      const successCount = updatedSubmissions.filter(s => s.authenticityScore !== undefined).length;
      const errorCount = updatedSubmissions.filter(s => s.analysisError).length;

      if (successCount > 0) {
        setSuccess(`AI analysis complete! ${successCount} analyzed successfully${errorCount > 0 ? `, ${errorCount} failed` : ''}. Review the scores below before saving to database.`);
      }
    } catch (err: any) {
      setError(`Error analyzing submissions: ${err.message}`);
      console.error(err);
    } finally {
      setLoading(false);
      setCurrentAnalysisIndex(-1);
      setEstimatedTimeRemaining('');
    }
  }

  async function checkForDuplicates(submissions: ParsedSubmission[]) {
    let duplicateCount = 0;
    const duplicateDetails: string[] = [];

    for (const submission of submissions) {
      let { data: student } = await supabase
        .from('students')
        .select('id')
        .eq('email', submission.studentEmail)
        .maybeSingle();

      if (!student) continue;

      let { data: discussion } = await supabase
        .from('discussions')
        .select('id')
        .eq('title', submission.discussionTitle)
        .eq('section', submission.section)
        .maybeSingle();

      if (!discussion) continue;

      const { data: existingSubmission } = await supabase
        .from('submissions')
        .select('id')
        .eq('student_id', student.id)
        .eq('discussion_id', discussion.id)
        .eq('post_text', submission.postText)
        .maybeSingle();

      if (existingSubmission) {
        duplicateCount++;
        duplicateDetails.push(`${submission.studentName} - ${submission.discussionTitle}`);
      }
    }

    setParsedData(submissions);

    if (duplicateCount > 0) {
      setError(`Found ${duplicateCount} duplicate submission(s) already in database:\n${duplicateDetails.join('\n')}`);
    } else {
      setSuccess(`Successfully parsed ${submissions.length} submission(s). No duplicates found.`);
    }
  }

  function parseTimestampToISO(timestamp: string): string | null {
    if (!timestamp || timestamp.trim() === '') return null;

    try {
      const match = timestamp.match(/(\d{1,2}):(\d{2})\s+(AM|PM),\s+(\d{1,2})\/(\d{1,2})\/(\d{4})/);
      if (!match) return null;

      let hours = parseInt(match[1]);
      const minutes = match[2];
      const meridiem = match[3];
      const month = match[4].padStart(2, '0');
      const day = match[5].padStart(2, '0');
      const year = match[6];

      if (meridiem === 'PM' && hours !== 12) hours += 12;
      if (meridiem === 'AM' && hours === 12) hours = 0;

      const hoursStr = hours.toString().padStart(2, '0');

      return `${year}-${month}-${day}T${hoursStr}:${minutes}:00`;
    } catch (err) {
      console.error('Error parsing timestamp:', timestamp, err);
      return null;
    }
  }

  async function saveToDatabase() {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      let savedCount = 0;
      let skippedCount = 0;

      for (const submission of parsedData) {
        let { data: student } = await supabase
          .from('students')
          .select('*')
          .eq('email', submission.studentEmail)
          .maybeSingle();

        if (!student) {
          const { data: newStudent, error: studentError } = await supabase
            .from('students')
            .insert({
              name: submission.studentName,
              email: submission.studentEmail,
              section: submission.section,
            })
            .select()
            .single();

          if (studentError) throw studentError;
          student = newStudent;
        }

        let { data: discussion } = await supabase
          .from('discussions')
          .select('*')
          .eq('title', submission.discussionTitle)
          .eq('section', submission.section)
          .maybeSingle();

        if (!discussion) {
          const { data: newDiscussion, error: discussionError } = await supabase
            .from('discussions')
            .insert({
              title: submission.discussionTitle,
              section: submission.section,
              discussion_date: submission.discussionDate,
            })
            .select()
            .single();

          if (discussionError) throw discussionError;
          discussion = newDiscussion;
        }

        const { data: existingSubmission } = await supabase
          .from('submissions')
          .select('id')
          .eq('student_id', student.id)
          .eq('discussion_id', discussion.id)
          .eq('post_text', submission.postText)
          .maybeSingle();

        if (existingSubmission) {
          skippedCount++;
          continue;
        }

        const { data: newSubmission, error: submissionError } = await supabase
          .from('submissions')
          .insert({
            student_id: student.id,
            discussion_id: discussion.id,
            post_text: submission.postText,
            post_timestamp: parseTimestampToISO(submission.postTimestamp),
            response_score: submission.responseScore,
            submission_type: submission.isQuestion ? 'question' : 'response',
          })
          .select()
          .single();

        if (submissionError) throw submissionError;
        savedCount++;

        if (submission.authenticityScore !== undefined && newSubmission) {
          const { error: analysisError } = await supabase.from('analysis_results').insert({
            submission_id: newSubmission.id,
            authenticity_score: submission.authenticityScore,
            red_flags: submission.redFlags || [],
            explanation: submission.explanation || '',
          });

          if (analysisError) throw analysisError;

          if (submission.authenticityScore >= 3 && !student.first_flagged_date) {
            await supabase
              .from('students')
              .update({ first_flagged_date: new Date().toISOString() })
              .eq('id', student.id);
          }
        }
      }

      const messages = [];
      if (savedCount > 0) messages.push(`Saved ${savedCount} new submission(s)`);
      if (skippedCount > 0) messages.push(`Skipped ${skippedCount} duplicate(s)`);

      setSuccess(messages.join('. '));
      setTextInput('');
      setParsedData([]);
    } catch (err: any) {
      setError(`Error saving to database: ${err.message}`);
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-blue-100 rounded-lg">
            <Upload className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Upload Submissions</h2>
            <p className="text-sm text-gray-500">
              Upload files or paste Packback discussion data
            </p>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Option 1: Upload Files</h3>
          <div
            onDrop={handleFileDrop}
            onDragOver={handleDragOver}
            className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".txt,.csv,.tsv,.pdf"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-700 font-medium mb-2">
              Drop files here or click to browse
            </p>
            <p className="text-sm text-gray-500">
              Supports .txt, .csv, .tsv, .pdf files (single or multiple)
            </p>
          </div>

          {uploadedFiles.length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-700 mb-2">
                Selected Files ({uploadedFiles.length})
              </h4>
              <div className="space-y-2">
                {uploadedFiles.map((file, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg border border-gray-200"
                  >
                    <File className="w-5 h-5 text-blue-600" />
                    <span className="text-sm text-gray-900 flex-1">{file.name}</span>
                    <span className="text-xs text-gray-500">
                      {(file.size / 1024).toFixed(1)} KB
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setUploadedFiles((prev) => prev.filter((_, i) => i !== index));
                      }}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
              <button
                onClick={processFiles}
                disabled={loading}
                className="mt-4 w-full flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
              >
                <FileText className="w-5 h-5" />
                <span>{loading ? 'Processing...' : `Process ${uploadedFiles.length} File(s)`}</span>
              </button>
            </div>
          )}
        </div>

        <div className="border-t border-gray-200 pt-8">
          <button
            onClick={() => setPasteTextExpanded(!pasteTextExpanded)}
            className="flex items-center space-x-2 text-lg font-semibold text-gray-900 hover:text-gray-700 transition-colors mb-4"
          >
            {pasteTextExpanded ? (
              <ChevronDown className="w-5 h-5" />
            ) : (
              <ChevronRight className="w-5 h-5" />
            )}
            <span>Option 2: Paste Text</span>
          </button>

          {pasteTextExpanded && (
            <>
              <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Format Example:</h4>
                <pre className="text-xs text-gray-600 overflow-x-auto">
                  {`Student: John Doe
Email: john.doe@university.edu
Section: Section 01
Discussion: What are the ethical implications of AI?
Date: 2024-01-15
Posted: 2024-01-15 14:30:00
Score: 85
Post: This is the student's response text here. It can be multiple lines long and contain their full submission to the Packback discussion.

Student: Jane Smith
Email: jane.smith@university.edu
...`}
                </pre>
              </div>
            </>
          )}

          {pasteTextExpanded && (
            <>
              {error && (
                <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-red-800">{error}</div>
                </div>
              )}

              {success && (
                <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-green-800">{success}</div>
                </div>
              )}

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Paste Submission Data
                </label>
                <textarea
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Paste formatted submission data here..."
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm resize-y"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={parseSubmissions}
                  disabled={!textInput.trim() || loading}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed transition-colors"
                >
                  <FileText className="w-5 h-5" />
                  <span>Parse Data</span>
                </button>

                <button
                  onClick={saveToDatabase}
                  disabled={parsedData.length === 0 || !parsedData.some(s => s.authenticityScore !== undefined) || loading}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  <CheckCircle className="w-5 h-5" />
                  <span>{loading ? 'Saving...' : 'Save to Database'}</span>
                </button>
              </div>
            </>
          )}
        </div>

        {parsedData.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Parsed Submissions ({parsedData.length})
              </h3>
              {!parsedData.some(s => s.authenticityScore !== undefined) && (
                <button
                  onClick={analyzeSubmissions}
                  disabled={loading}
                  className="flex flex-col items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-5 h-5" />
                    <span>{loading ? 'Analyzing...' : 'Analyze with AI'}</span>
                  </div>
                  {loading && currentAnalysisIndex > 0 && (
                    <div className="text-xs mt-2 space-y-1">
                      <div>Progress: {currentAnalysisIndex} of {totalAnalysis}</div>
                      {estimatedTimeRemaining && (
                        <div>Est. time remaining: {estimatedTimeRemaining}</div>
                      )}
                    </div>
                  )}
                </button>
              )}
            </div>
            <div className="space-y-4">
              {parsedData.map((submission, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    submission.authenticityScore !== undefined && submission.authenticityScore >= 4
                      ? 'bg-red-50 border-red-300'
                      : submission.authenticityScore !== undefined && submission.authenticityScore >= 3
                      ? 'bg-yellow-50 border-yellow-300'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="grid grid-cols-2 gap-4 flex-1">
                      <div>
                        <span className="text-xs font-medium text-gray-500">Student:</span>
                        <p className="text-sm text-gray-900">{submission.studentName}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-500">Email:</span>
                        <p className="text-sm text-gray-900">{submission.studentEmail}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-500">Discussion:</span>
                        <p className="text-sm text-gray-900">{submission.discussionTitle}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-gray-500">Packback Score:</span>
                        <p className="text-sm text-gray-900">{submission.responseScore}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const updated = [...parsedData];
                        updated[index].isQuestion = !updated[index].isQuestion;
                        setParsedData(updated);
                      }}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg border-2 transition-all ${
                        submission.isQuestion
                          ? 'bg-blue-50 border-blue-500 text-blue-700'
                          : 'bg-gray-50 border-gray-300 text-gray-600 hover:border-gray-400'
                      }`}
                      title={submission.isQuestion ? 'Marked as Question' : 'Marked as Response'}
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-xs font-medium">
                        {submission.isQuestion ? 'Question' : 'Response'}
                      </span>
                    </button>
                  </div>

                  {submission.analyzing && (
                    <div className="mb-3 p-3 bg-blue-50 rounded-lg border border-blue-300">
                      <div className="flex items-center space-x-2 mb-1">
                        <Sparkles className="w-5 h-5 animate-pulse text-blue-600" />
                        <span className="text-sm text-blue-900 font-medium">Analyzing with AI...</span>
                      </div>
                      <p className="text-xs text-blue-700 ml-7">AI servers may be slow to respond. Please be patient...</p>
                    </div>
                  )}

                  {submission.analysisError && (
                    <div className="mb-3 p-3 bg-red-50 rounded-lg border border-red-300 flex items-start space-x-2">
                      <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <div className="text-sm text-red-900 font-medium mb-1">Analysis Failed</div>
                        <div className="text-xs text-red-700 mb-2">{submission.analysisError}</div>
                        {submission.analysisError.toLowerCase().includes('overload') && (
                          <div className="text-xs text-red-800 bg-red-100 p-2 rounded mb-2">
                            <strong>AI servers are overloaded.</strong> This is temporary - try again in 15 minutes, or wait a few moments and click Retry below.
                          </div>
                        )}
                        {submission.analysisError.toLowerCase().includes('rate limit') && (
                          <div className="text-xs text-red-800 bg-red-100 p-2 rounded mb-2">
                            <strong>Rate limit reached.</strong> Wait a few minutes before retrying to allow the API quota to reset.
                          </div>
                        )}
                        <button
                          onClick={async () => {
                            const { data: settings } = await supabase
                              .from('settings')
                              .select('value')
                              .eq('key', 'api_key')
                              .maybeSingle();

                            const apiKey = settings?.value?.anthropic;
                            if (!apiKey) {
                              setError('No API key configured. Please add your Claude API key in Settings.');
                              return;
                            }

                            const updated = [...parsedData];
                            const idx = parsedData.indexOf(submission);
                            updated[idx].analyzing = true;
                            updated[idx].analysisError = undefined;
                            setParsedData([...updated]);

                            try {
                              const analysis = await analyzeSubmission(
                                submission.postText,
                                apiKey,
                                submission.isQuestion || false
                              );

                              updated[idx].authenticityScore = analysis.authenticityScore;
                              updated[idx].redFlags = analysis.redFlags;
                              updated[idx].explanation = analysis.explanation;
                              updated[idx].analyzing = false;
                            } catch (err: any) {
                              updated[idx].analyzing = false;
                              updated[idx].analysisError = err.message;
                            }

                            setParsedData([...updated]);
                          }}
                          className="mt-2 px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700 transition-colors"
                        >
                          Retry Analysis
                        </button>
                      </div>
                    </div>
                  )}

                  {submission.authenticityScore !== undefined && (
                    <div className="mb-3 p-3 bg-white rounded-lg border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-medium text-gray-500">AI Authenticity Score:</span>
                        <div className="flex items-center space-x-2">
                          {submission.authenticityScore >= 4 && (
                            <AlertTriangle className="w-5 h-5 text-red-600" />
                          )}
                          {submission.authenticityScore === 3 && (
                            <AlertCircle className="w-5 h-5 text-yellow-600" />
                          )}
                          <span className={`text-2xl font-bold ${
                            submission.authenticityScore >= 4 ? 'text-red-600' :
                            submission.authenticityScore >= 3 ? 'text-yellow-600' :
                            'text-green-600'
                          }`}>
                            {submission.authenticityScore}/5
                          </span>
                        </div>
                      </div>
                      <div className="text-xs text-gray-600 mb-1">
                        {submission.isQuestion ? (
                          <>
                            {submission.authenticityScore === 0 && '✓ Clearly authentic question'}
                            {submission.authenticityScore === 1 && '✓ Mostly authentic question'}
                            {submission.authenticityScore === 2 && '✓ Likely authentic question'}
                            {submission.authenticityScore === 3 && '⚠ Somewhat formal (acceptable for questions)'}
                            {submission.authenticityScore === 4 && '⚠ PhD-level sophistication detected'}
                            {submission.authenticityScore === 5 && '⚠ Almost certainly AI-generated question'}
                          </>
                        ) : (
                          <>
                            {submission.authenticityScore === 0 && '✓ Clearly authentic'}
                            {submission.authenticityScore === 1 && '✓ Mostly authentic'}
                            {submission.authenticityScore === 2 && '✓ Likely authentic'}
                            {submission.authenticityScore === 3 && '⚠ Suspicious - needs review'}
                            {submission.authenticityScore === 4 && '⚠ Likely AI-generated'}
                            {submission.authenticityScore === 5 && '⚠ Almost certainly AI-generated'}
                          </>
                        )}
                      </div>
                      {submission.redFlags && submission.redFlags.length > 0 && (
                        <div className="mt-2">
                          <span className="text-xs font-medium text-gray-700">Red Flags:</span>
                          <ul className="text-xs text-gray-600 list-disc list-inside mt-1">
                            {submission.redFlags.map((flag, i) => (
                              <li key={i}>{flag}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      {submission.explanation && (
                        <details className="mt-2">
                          <summary className="text-xs font-medium text-gray-700 cursor-pointer hover:text-gray-900">
                            View Analysis Details
                          </summary>
                          <p className="text-xs text-gray-600 mt-2 whitespace-pre-wrap">
                            {submission.explanation}
                          </p>
                        </details>
                      )}
                    </div>
                  )}

                  <div>
                    <span className="text-xs font-medium text-gray-500">Post Preview:</span>
                    <p className="text-sm text-gray-700 line-clamp-3 mt-1">
                      {submission.postText}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            {parsedData.some(s => s.authenticityScore !== undefined) && (
              <div className="mt-6 flex space-x-4">
                <button
                  onClick={parseSubmissions}
                  disabled={!textInput.trim() || loading}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 disabled:bg-gray-100 disabled:cursor-not-allowed transition-colors"
                >
                  <FileText className="w-5 h-5" />
                  <span>Parse Data</span>
                </button>

                <button
                  onClick={saveToDatabase}
                  disabled={loading}
                  className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  <CheckCircle className="w-5 h-5" />
                  <span>{loading ? 'Saving...' : 'Save to Database'}</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
