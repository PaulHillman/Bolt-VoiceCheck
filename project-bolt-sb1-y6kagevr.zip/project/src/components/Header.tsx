import { Settings, History, LogOut, Zap } from 'lucide-react';

interface HeaderProps {
  onNavigate: (view: string) => void;
  currentView: string;
  onLogout?: () => void;
}

export function Header({ onNavigate, currentView, onLogout }: HeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <img
              src="/VoiceCheckLogo_Writing.png"
              alt="VoiceCheck - Authentic Writing Detection"
              className="h-16 w-auto object-contain"
            />
          </div>

          <nav className="flex items-center space-x-6">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'dashboard'
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('upload')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'upload'
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Upload
            </button>
            <button
              onClick={() => onNavigate('quick-analysis')}
              className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                currentView === 'quick-analysis'
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>Quick Analysis</span>
            </button>
            <button
              onClick={() => onNavigate('emails')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'emails'
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Emails
            </button>
            <button
              onClick={() => onNavigate('email-logs')}
              className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                currentView === 'email-logs'
                  ? 'text-blue-600'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Email Logs</span>
            </button>
            <button
              onClick={() => onNavigate('settings')}
              className={`p-2 text-gray-600 hover:text-gray-900 transition-colors ${
                currentView === 'settings' ? 'text-blue-600' : ''
              }`}
            >
              <Settings className="w-5 h-5" />
            </button>
            {onLogout && (
              <div className="border-l border-gray-300 pl-6 ml-2">
                <button
                  onClick={onLogout}
                  className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
