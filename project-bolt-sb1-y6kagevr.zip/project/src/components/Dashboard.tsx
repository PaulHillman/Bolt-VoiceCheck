import { useEffect, useState } from 'react';
import { supabase, Student, Submission, AnalysisResult } from '../lib/supabase';
import { AlertCircle, Users, Bell, CheckCircle, XCircle, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';

interface DashboardProps {
  onViewStudent: (studentId: string) => void;
}

interface StudentWithAnalysis extends Student {
  latestSubmission?: Submission;
  latestAnalysis?: AnalysisResult;
  warningCount: number;
  lastWarningDate?: string;
  analyzedSubmissionsCount: number;
  totalSubmissionsCount: number;
  averageAuthenticityScore: number | null;
  highestAuthenticityScore: number | null;
  lastLoginDate?: string;
  totalLogins: number;
  lastAnalyzedDate?: string;
}

type SortField = 'name' | 'section' | 'warnings' | 'status' | 'avgScore' | 'lastAnalyzed';
type SortDirection = 'asc' | 'desc';

export function Dashboard({ onViewStudent }: DashboardProps) {
  const [students, setStudents] = useState<StudentWithAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'flagged' | 'repeat' | 'unanalyzed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sectionFilter, setSectionFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  useEffect(() => {
    loadStudents();
  }, []);

  async function loadStudents() {
    try {
      console.log('=== DASHBOARD LOADING START ===');
      console.log('[Dashboard] Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
      console.log('[Dashboard] Anon Key exists:', !!import.meta.env.VITE_SUPABASE_ANON_KEY);
      console.log('[Dashboard] Loading students from Supabase...');

      const { data: studentsData, error: studentsError } = await supabase
        .from('students')
        .select('*')
        .order('updated_at', { ascending: false });

      console.log('[Dashboard] Students query completed');
      console.log('[Dashboard] Students data:', studentsData);
      console.log('[Dashboard] Students error:', studentsError);
      console.log('[Dashboard] Students count:', studentsData?.length ?? 0);

      if (studentsError) {
        console.error('[Dashboard] ERROR loading students:', studentsError);
        alert(`Failed to load students: ${studentsError.message}\n\nDetails: ${JSON.stringify(studentsError, null, 2)}`);
        throw studentsError;
      }

      if (!studentsData || studentsData.length === 0) {
        console.warn('[Dashboard] No students found in database');
        setLoading(false);
        return;
      }

      const studentsWithData = await Promise.all(
        (studentsData || []).map(async (student) => {
          const { data: allSubmissions } = await supabase
            .from('submissions')
            .select('id')
            .eq('student_id', student.id);

          const totalSubmissionsCount = allSubmissions?.length || 0;

          const { data: submissions } = await supabase
            .from('submissions')
            .select('*')
            .eq('student_id', student.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          let analysis = null;
          if (submissions) {
            const { data: analysisData } = await supabase
              .from('analysis_results')
              .select('*')
              .eq('submission_id', submissions.id)
              .maybeSingle();
            analysis = analysisData;
          }

          const { data: analyzedSubmissions } = await supabase
            .from('submissions')
            .select('id, analysis_results(authenticity_score)')
            .eq('student_id', student.id);

          const submissionsWithAnalysis = analyzedSubmissions?.filter(
            (sub: any) => sub.analysis_results && sub.analysis_results.length > 0
          ) || [];

          const analyzedSubmissionsCount = submissionsWithAnalysis.length;

          const scores = submissionsWithAnalysis
            .map((sub: any) => sub.analysis_results[0]?.authenticity_score)
            .filter((score: number) => score !== undefined && score !== null);

          const averageAuthenticityScore = scores.length > 0
            ? scores.reduce((a: number, b: number) => a + b, 0) / scores.length
            : null;

          const highestAuthenticityScore = scores.length > 0
            ? Math.max(...scores)
            : null;

          const { data: warnings } = await supabase
            .from('warnings')
            .select('*')
            .eq('student_id', student.id)
            .order('sent_date', { ascending: false });

          const { data: logins } = await supabase
            .from('student_logins')
            .select('*')
            .eq('g_number', student.g_number)
            .order('logged_in_at', { ascending: false });

          const { data: latestAnalyzed } = await supabase
            .from('analysis_results')
            .select('created_at, submission_id')
            .in('submission_id', (analyzedSubmissions || []).map((s: any) => s.id))
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          return {
            ...student,
            latestSubmission: submissions || undefined,
            latestAnalysis: analysis || undefined,
            warningCount: warnings?.length || 0,
            lastWarningDate: warnings?.[0]?.sent_date,
            analyzedSubmissionsCount,
            totalSubmissionsCount,
            averageAuthenticityScore,
            highestAuthenticityScore,
            lastLoginDate: logins?.[0]?.logged_in_at,
            totalLogins: logins?.length || 0,
            lastAnalyzedDate: latestAnalyzed?.created_at,
          };
        })
      );

      console.log(`[Dashboard] Loaded ${studentsWithData.length} students with complete data`);
      console.log('[Dashboard] Students with data:', studentsWithData);
      setStudents(studentsWithData);
      console.log('=== DASHBOARD LOADING COMPLETE ===');
    } catch (error) {
      console.error('[Dashboard] UNEXPECTED ERROR:', error);
      if (error instanceof Error) {
        alert(`Error loading data: ${error.message}\n\nStack: ${error.stack}`);
      } else {
        alert(`Error loading data: ${JSON.stringify(error, null, 2)}`);
      }
    } finally {
      console.log('[Dashboard] Setting loading to false');
      setLoading(false);
    }
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getLastName = (fullName: string) => {
    const parts = fullName.trim().split(' ');
    return parts[parts.length - 1].toLowerCase();
  };

  const getFirstName = (fullName: string) => {
    const parts = fullName.trim().split(' ');
    return parts[0].toLowerCase();
  };

  const getStatusValue = (student: StudentWithAnalysis) => {
    const avgScore = student.averageAuthenticityScore;
    if (avgScore === null) return 0;
    if (avgScore >= 4) return 3; // High Risk
    if (avgScore >= 3) return 2; // Suspicious
    return 1; // Authentic
  };

  const filteredStudents = students
    .filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase());

      if (!matchesSearch) return false;

      if (sectionFilter !== 'all' && student.section !== sectionFilter) {
        return false;
      }

      if (filter === 'flagged') {
        return (student.highestAuthenticityScore || 0) >= 3;
      }
      if (filter === 'repeat') {
        return student.warningCount >= 2;
      }
      if (filter === 'unanalyzed') {
        return student.totalSubmissionsCount === 0;
      }
      return true;
    })
    .sort((a, b) => {
      let comparison = 0;

      switch (sortField) {
        case 'name':
          const aLastName = getLastName(a.name);
          const bLastName = getLastName(b.name);
          comparison = aLastName.localeCompare(bLastName);
          if (comparison === 0) {
            const aFirstName = getFirstName(a.name);
            const bFirstName = getFirstName(b.name);
            comparison = aFirstName.localeCompare(bFirstName);
          }
          break;
        case 'section':
          comparison = (a.section || '').localeCompare(b.section || '');
          break;
        case 'warnings':
          comparison = a.warningCount - b.warningCount;
          break;
        case 'status':
          comparison = getStatusValue(a) - getStatusValue(b);
          break;
        case 'avgScore':
          const aScore = a.averageAuthenticityScore ?? -1;
          const bScore = b.averageAuthenticityScore ?? -1;
          comparison = aScore - bScore;
          break;
        case 'lastAnalyzed':
          const aDate = a.lastAnalyzedDate ? new Date(a.lastAnalyzedDate).getTime() : 0;
          const bDate = b.lastAnalyzedDate ? new Date(b.lastAnalyzedDate).getTime() : 0;
          comparison = aDate - bDate;
          break;
      }

      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const uniqueSections = Array.from(new Set(students.map(s => s.section).filter(Boolean))).sort();

  const stats = {
    total: students.length,
    analyzed: students.filter((s) => s.analyzedSubmissionsCount > 0).length,
    unanalyzed: students.filter((s) => s.totalSubmissionsCount === 0).length,
    flagged: students.filter((s) => (s.highestAuthenticityScore || 0) >= 3).length,
    firstWarning: students.filter((s) => s.warningCount === 1).length,
    secondWarning: students.filter((s) => s.warningCount === 2).length,
    thirdWarning: students.filter((s) => s.warningCount >= 3).length,
  };

  function getScoreColor(score: number) {
    if (score <= 2) return 'text-green-600 bg-green-50';
    if (score === 3) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  }

  function getWarningBadgeColor(count: number) {
    if (count === 0) return 'bg-gray-100 text-gray-600';
    if (count === 1) return 'bg-yellow-100 text-yellow-700';
    if (count === 2) return 'bg-orange-100 text-orange-700';
    return 'bg-red-100 text-red-700';
  }

  console.log('[Dashboard] Render - loading:', loading, 'students count:', students.length);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-500">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  if (students.length === 0) {
    console.warn('[Dashboard] No students loaded!');
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-yellow-900 mb-2">No Students Found</h3>
          <p className="text-yellow-700">
            The dashboard couldn't load any student data. This could mean:
          </p>
          <ul className="list-disc list-inside text-yellow-700 mt-2 space-y-1">
            <li>The database is empty</li>
            <li>There's a permissions issue</li>
            <li>The database connection failed</li>
          </ul>
          <p className="text-yellow-700 mt-4">Check the browser console for detailed error messages.</p>
          <button
            onClick={loadStudents}
            className="mt-4 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700"
          >
            Retry Loading
          </button>
        </div>
      </div>
    );
  }

  console.log('[Dashboard] Rendering dashboard with stats:', stats);
  console.log('[Dashboard] Filtered students count:', filteredStudents.length);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Students</p>
              <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
            </div>
            <Users className="w-10 h-10 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Analyzed</p>
              <p className="text-3xl font-bold text-green-600">{stats.analyzed}</p>
            </div>
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Unanalyzed</p>
              <p className="text-3xl font-bold text-gray-600">{stats.unanalyzed}</p>
            </div>
            <XCircle className="w-10 h-10 text-gray-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Flagged</p>
              <p className="text-3xl font-bold text-yellow-600">{stats.flagged}</p>
            </div>
            <AlertCircle className="w-10 h-10 text-yellow-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">First Warning</p>
              <p className="text-3xl font-bold text-yellow-700">{stats.firstWarning}</p>
            </div>
            <Bell className="w-10 h-10 text-yellow-700" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Second Warning</p>
              <p className="text-3xl font-bold text-orange-600">{stats.secondWarning}</p>
            </div>
            <Bell className="w-10 h-10 text-orange-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Third Warning</p>
              <p className="text-3xl font-bold text-red-600">{stats.thirdWarning}</p>
            </div>
            <Bell className="w-10 h-10 text-red-600" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filter === 'all'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All Students
                </button>
                <button
                  onClick={() => setFilter('unanalyzed')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filter === 'unanalyzed'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Unanalyzed
                </button>
                <button
                  onClick={() => setFilter('flagged')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filter === 'flagged'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Flagged Only
                </button>
                <button
                  onClick={() => setFilter('repeat')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    filter === 'repeat'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Repeat Offenders
                </button>
              </div>

              <div className="flex gap-2">
                <select
                  value={sectionFilter}
                  onChange={(e) => setSectionFilter(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
                >
                  <option value="all">All Sections</option>
                  {uniqueSections.map((section) => (
                    <option key={section} value={section}>
                      {section}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('name')}
                >
                  <div className="flex items-center gap-2">
                    Student
                    {sortField === 'name' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('section')}
                >
                  <div className="flex items-center gap-2">
                    Section
                    {sortField === 'section' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Analyzed
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('avgScore')}
                >
                  <div className="flex items-center gap-2">
                    Avg Score
                    {sortField === 'avgScore' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('warnings')}
                >
                  <div className="flex items-center gap-2">
                    Warnings
                    {sortField === 'warnings' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('lastAnalyzed')}
                >
                  <div className="flex items-center gap-2">
                    Last Analyzed
                    {sortField === 'lastAnalyzed' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Warning
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Login
                </th>
                <th
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => handleSort('status')}
                >
                  <div className="flex items-center gap-2">
                    Status
                    {sortField === 'status' ? (
                      sortDirection === 'asc' ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />
                    ) : (
                      <ArrowUpDown className="w-4 h-4 opacity-40" />
                    )}
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredStudents.map((student) => {
                const avgScore = student.averageAuthenticityScore;
                const displayScore = avgScore !== null ? Math.round(avgScore * 10) / 10 : null;
                return (
                  <tr
                    key={student.id}
                    onClick={() => onViewStudent(student.id)}
                    className="hover:bg-gray-50 cursor-pointer transition-colors"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{student.name}</div>
                        <div className="text-sm text-gray-500">{student.email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {student.section || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm">
                        <span className="font-medium text-gray-900">
                          {student.analyzedSubmissionsCount}
                        </span>
                        <span className="text-gray-500">
                          {' '}/{' '}{student.totalSubmissionsCount}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {displayScore !== null ? (
                        <span
                          className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getScoreColor(
                            displayScore
                          )}`}
                        >
                          {displayScore}/5
                        </span>
                      ) : (
                        <span className="text-sm text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getWarningBadgeColor(
                          student.warningCount
                        )}`}
                      >
                        {student.warningCount}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {student.lastAnalyzedDate ? (
                        <>
                          <div className="text-gray-900">
                            {new Date(student.lastAnalyzedDate).toLocaleDateString()}
                          </div>
                          <div className="text-gray-500 text-xs">
                            {new Date(student.lastAnalyzedDate).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </div>
                        </>
                      ) : (
                        <span className="text-gray-400">Never</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {student.lastWarningDate
                        ? new Date(student.lastWarningDate).toLocaleDateString()
                        : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm">
                        {student.lastLoginDate ? (
                          <>
                            <div className="text-gray-900">
                              {new Date(student.lastLoginDate).toLocaleDateString()}
                            </div>
                            <div className="text-gray-500 text-xs">
                              {student.totalLogins} login{student.totalLogins !== 1 ? 's' : ''}
                            </div>
                          </>
                        ) : (
                          <span className="text-gray-400">Never</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {displayScore === null ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                          No Data
                        </span>
                      ) : displayScore >= 4 ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          High Risk
                        </span>
                      ) : displayScore >= 3 ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                          Suspicious
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Authentic
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredStudents.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              No students found matching your criteria.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
