import { useState, useEffect } from 'react';
import { FileText, Upload, Loader2, AlertCircle, Mail, Send } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';
import { supabase } from '../lib/supabase';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';

interface AnalysisResult {
  authenticity_score: number;
  analysis_text: string;
  flagged_sections: string[];
  recommendations: string[];
}

interface EmailDraft {
  to: string;
  subject: string;
  body: string;
}

export function QuickAnalysis() {
  const [file, setFile] = useState<File | null>(null);
  const [content, setContent] = useState<string>('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string>('');
  const [emailDraft, setEmailDraft] = useState<EmailDraft | null>(null);
  const [showEmailEditor, setShowEmailEditor] = useState(false);
  const [sending, setSending] = useState(false);
  const [apiKey, setApiKey] = useState<string>('');

  useEffect(() => {
    loadApiKey();
  }, []);

  async function loadApiKey() {
    try {
      const { data } = await supabase
        .from('settings')
        .select('*')
        .eq('key', 'api_key')
        .maybeSingle();

      if (data?.value?.anthropic) {
        setApiKey(data.value.anthropic);
      }
    } catch (err) {
      console.error('Error loading API key:', err);
    }
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setResult(null);
    setError('');

    if (selectedFile.type === 'application/pdf') {
      try {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let fullText = '';

        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          const pageText = textContent.items
            .map((item: any) => item.str)
            .join(' ');
          fullText += pageText + '\n';
        }

        setContent(fullText);
      } catch (err) {
        setError('Failed to extract text from PDF');
        console.error(err);
      }
    } else if (selectedFile.type === 'text/plain') {
      try {
        const text = await selectedFile.text();
        setContent(text);
      } catch (err) {
        setError('Failed to read text file');
        console.error(err);
      }
    } else {
      setError('Please upload a PDF or text file');
      setFile(null);
    }
  };

  const handleAnalyze = async () => {
    if (!content) {
      setError('No content to analyze');
      return;
    }

    setAnalyzing(true);
    setError('');

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-submission`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            content,
            mode: 'generic',
          }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Analysis failed');
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Failed to analyze document. Please try again.');
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score <= 2) return 'text-green-600 bg-green-50 border-green-200';
    if (score <= 3) return 'text-yellow-600 bg-yellow-50 border-yellow-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  const getScoreLabel = (score: number) => {
    if (score <= 2) return 'Authentic';
    if (score <= 3) return 'Review Needed';
    return 'High Risk';
  };

  const generateEmail = () => {
    if (!result) return;

    const scoreLabel = getScoreLabel(result.authenticity_score);
    const fileName = file?.name || 'document';

    let subject = '';
    let body = '';

    if (result.authenticity_score <= 2) {
      subject = `Writing Analysis Results: ${fileName}`;
      body = `Dear Writer,

I've completed my analysis of "${fileName}" and I'm pleased to share positive feedback.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTHENTICITY SCORE: ${result.authenticity_score.toFixed(1)}/5 (${scoreLabel})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ANALYSIS:
${result.analysis_text}

${result.recommendations.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SUGGESTIONS FOR CONTINUED EXCELLENCE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${result.recommendations.map((r, i) => `${i + 1}. ${r}`).join('\n\n')}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Keep up the excellent work!

Best regards`;
    } else if (result.authenticity_score <= 3) {
      subject = `Writing Analysis Review: ${fileName}`;
      body = `Dear Writer,

I've completed my analysis of "${fileName}" and wanted to share some observations that warrant discussion.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTHENTICITY SCORE: ${result.authenticity_score.toFixed(1)}/5 (${scoreLabel})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ANALYSIS:
${result.analysis_text}

${result.flagged_sections.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AREAS FOR DISCUSSION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${result.flagged_sections.map((s, i) => `${i + 1}. ${s}`).join('\n\n')}` : ''}

${result.recommendations.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RECOMMENDATIONS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${result.recommendations.map((r, i) => `${i + 1}. ${r}`).join('\n\n')}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

I'd like to schedule a time to discuss this analysis in more detail.

Best regards`;
    } else {
      subject = `Important: Writing Analysis Concerns - ${fileName}`;
      body = `Dear Writer,

I've completed my analysis of "${fileName}" and need to discuss some significant concerns.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTHENTICITY SCORE: ${result.authenticity_score.toFixed(1)}/5 (${scoreLabel})
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ANALYSIS:
${result.analysis_text}

${result.flagged_sections.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SPECIFIC CONCERNS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${result.flagged_sections.map((s, i) => `${i + 1}. ${s}`).join('\n\n')}` : ''}

${result.recommendations.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NEXT STEPS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

${result.recommendations.map((r, i) => `${i + 1}. ${r}`).join('\n\n')}` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Please contact me at your earliest convenience to discuss this matter.

Best regards`;
    }

    setEmailDraft({
      to: '',
      subject,
      body,
    });
    setShowEmailEditor(true);
  };

  const handleSendEmail = async () => {
    if (!emailDraft || !emailDraft.to) {
      setError('Please enter a recipient email address');
      return;
    }

    setSending(true);
    setError('');

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-email`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            to: emailDraft.to,
            subject: emailDraft.subject,
            body: emailDraft.body,
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to send email');
      }

      alert('Email sent successfully!');
      setShowEmailEditor(false);
      setEmailDraft(null);
    } catch (err) {
      setError('Failed to send email. Please try again.');
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Quick Analysis</h1>
        <p className="mt-2 text-gray-600">
          Upload any document for AI-generated writing analysis
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Upload Document
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg hover:border-blue-500 transition-colors">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none">
                  <span>Upload a file</span>
                  <input
                    type="file"
                    className="sr-only"
                    accept=".pdf,.txt"
                    onChange={handleFileChange}
                  />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">PDF or TXT up to 10MB</p>
            </div>
          </div>
          {file && (
            <div className="mt-4 flex items-center gap-2 text-sm text-gray-700">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>{file.name}</span>
              <span className="text-gray-500">
                ({(file.size / 1024).toFixed(1)} KB)
              </span>
            </div>
          )}
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <button
          onClick={handleAnalyze}
          disabled={!content || analyzing}
          className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <FileText className="w-5 h-5" />
              Analyze Document
            </>
          )}
        </button>
      </div>

      {result && (
        <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
          <div className="border-b border-gray-200 pb-4">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Analysis Results</h2>
            <div className={`border-2 rounded-lg p-6 ${getScoreColor(result.authenticity_score)}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium mb-1">Authenticity Score</p>
                  <p className="text-4xl font-bold">{result.authenticity_score.toFixed(1)}/5</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">{getScoreLabel(result.authenticity_score)}</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Analysis</h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-gray-700 whitespace-pre-wrap">{result.analysis_text}</p>
            </div>
          </div>

          {result.flagged_sections.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Flagged Sections</h3>
              <div className="space-y-2">
                {result.flagged_sections.map((section, index) => (
                  <div key={index} className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <p className="text-sm text-gray-700">{section}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {result.recommendations.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Recommendations</h3>
              <ul className="space-y-2">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-blue-600 font-bold">•</span>
                    <span className="text-gray-700">{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="border-t border-gray-200 pt-6">
            <button
              onClick={generateEmail}
              className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Mail className="w-5 h-5" />
              Generate Email
            </button>
          </div>
        </div>
      )}

      {showEmailEditor && emailDraft && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Compose Email</h2>
                <button
                  onClick={() => {
                    setShowEmailEditor(false);
                    setError('');
                  }}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>

              {error && (
                <div className="mb-4 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    To:
                  </label>
                  <input
                    type="email"
                    value={emailDraft.to}
                    onChange={(e) => setEmailDraft({ ...emailDraft, to: e.target.value })}
                    placeholder="recipient@example.com"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject:
                  </label>
                  <input
                    type="text"
                    value={emailDraft.subject}
                    onChange={(e) => setEmailDraft({ ...emailDraft, subject: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message:
                  </label>
                  <textarea
                    value={emailDraft.body}
                    onChange={(e) => setEmailDraft({ ...emailDraft, body: e.target.value })}
                    rows={16}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={handleSendEmail}
                    disabled={sending || !emailDraft.to}
                    className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  >
                    {sending ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        Send Email
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setShowEmailEditor(false);
                      setError('');
                    }}
                    className="px-6 py-3 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
