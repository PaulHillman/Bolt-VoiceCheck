import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Mail, Copy, Send, AlertCircle, CheckCircle } from 'lucide-react';
import { sendEmailAndRecord } from '../services/emailService';

interface EmailDraft {
  studentId: string;
  submissionId: string;
  studentName: string;
  studentEmail: string;
  warningNumber: number;
  subject: string;
  body: string;
}

interface EmailsViewProps {
  drafts: EmailDraft[];
  onRemoveDraft: (submissionId: string) => void;
}

export function EmailsView({ drafts, onRemoveDraft }: EmailsViewProps) {
  const [selectedDraft, setSelectedDraft] = useState<EmailDraft | null>(null);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isTestMode, setIsTestMode] = useState(false);

  useEffect(() => {
    if (drafts.length > 0 && !selectedDraft) {
      setSelectedDraft(drafts[0]);
    } else if (drafts.length === 0) {
      setSelectedDraft(null);
    } else if (selectedDraft && !drafts.find(d => d.submissionId === selectedDraft.submissionId)) {
      setSelectedDraft(drafts[0] || null);
    }
  }, [drafts]);


  async function sendEmailNow(draft: EmailDraft, testMode: boolean) {
    setIsSending(true);
    setError('');
    setSuccess('');

    try {
      const recipientEmail = testMode ? 'HillmanP@gvsu.edu' : draft.studentEmail;

      await sendEmailAndRecord(
        draft.studentId,
        draft.submissionId,
        draft.warningNumber,
        draft.subject,
        draft.body,
        recipientEmail
      );

      if (!testMode) {
        onRemoveDraft(draft.submissionId);
      }

      setSuccess(
        testMode
          ? `✓ Test email sent to HillmanP@gvsu.edu! Review it before sending to student.`
          : `✓ Email sent successfully to ${draft.studentEmail}! The warning has been recorded.`
      );
      setTimeout(() => setSuccess(''), 8000);
    } catch (err: any) {
      setError(`Failed to send email: ${err.message}`);
      console.error(err);
      setTimeout(() => setError(''), 5000);
    } finally {
      setIsSending(false);
    }
  }

  function copyToClipboard(text: string) {
    navigator.clipboard.writeText(text);
    setSuccess('Copied to clipboard!');
    setTimeout(() => setSuccess(''), 2000);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Email Management</h1>
        <p className="text-gray-600 mt-2">Generate and manage warning emails for students</p>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">{error}</div>
        </div>
      )}

      {success && (
        <div className="mb-4 p-5 bg-green-100 border-2 border-green-500 rounded-lg flex items-start space-x-3 shadow-md">
          <CheckCircle className="w-6 h-6 text-green-700 flex-shrink-0 mt-0.5" />
          <div className="text-base font-semibold text-green-900">{success}</div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Email Drafts</h2>
              <p className="text-sm text-gray-500 mt-1">{drafts.length} draft(s)</p>
            </div>
            <div className="divide-y divide-gray-200">
              {drafts.length === 0 && (
                <div className="p-6 text-center text-gray-500 text-sm">
                  No email drafts yet. Generate emails from the student detail view.
                </div>
              )}
              {drafts.map((draft, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedDraft(draft)}
                  className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                    selectedDraft === draft ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{draft.studentName}</div>
                      <div className="text-sm text-gray-500">{draft.studentEmail}</div>
                    </div>
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        draft.warningNumber === 1
                          ? 'bg-yellow-100 text-yellow-800'
                          : draft.warningNumber === 2
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      Warning #{draft.warningNumber}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          {selectedDraft ? (
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">
                      {selectedDraft.studentName}
                    </h2>
                    <p className="text-sm text-gray-500">{selectedDraft.studentEmail}</p>
                  </div>
                  <span
                    className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      selectedDraft.warningNumber === 1
                        ? 'bg-yellow-100 text-yellow-800'
                        : selectedDraft.warningNumber === 2
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {selectedDraft.warningNumber === 1 && 'First Warning'}
                    {selectedDraft.warningNumber === 2 && 'Second Warning'}
                    {selectedDraft.warningNumber === 3 && 'Third Warning - Meeting Required'}
                    {selectedDraft.warningNumber >= 4 &&
                      'Academic Integrity Violation - Grade Penalty'}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={selectedDraft.subject}
                    onChange={(e) =>
                      setSelectedDraft({ ...selectedDraft, subject: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Body
                  </label>
                  <textarea
                    value={selectedDraft.body}
                    onChange={(e) =>
                      setSelectedDraft({ ...selectedDraft, body: e.target.value })
                    }
                    rows={20}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  />
                </div>

                <div className="mb-4">
                  <label className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isTestMode}
                      onChange={(e) => setIsTestMode(e.target.checked)}
                      className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      Test Mode: Send to HillmanP@gvsu.edu instead of student
                    </span>
                  </label>
                  {isTestMode && (
                    <p className="text-xs text-blue-600 mt-2 ml-8">
                      Email will be sent to you for review. The draft will remain in the list.
                    </p>
                  )}
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() =>
                      copyToClipboard(
                        `Subject: ${selectedDraft.subject}\n\n${selectedDraft.body}`
                      )
                    }
                    className="flex items-center justify-center space-x-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    <Copy className="w-5 h-5" />
                    <span>Copy</span>
                  </button>
                  <button
                    onClick={() => sendEmailNow(selectedDraft, isTestMode)}
                    disabled={isSending}
                    className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                    <span>
                      {isSending
                        ? 'Sending...'
                        : isTestMode
                        ? 'Send Test Email'
                        : 'Send Email via Resend'}
                    </span>
                  </button>
                </div>

                {selectedDraft.warningNumber >= 3 && (
                  <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <div className="text-sm text-red-800">
                        <strong>Action Required:</strong> This is warning #{selectedDraft.warningNumber}. Consider scheduling a meeting with the student and documenting this for academic integrity records.
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-12 text-center">
              <Mail className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Email Selected</h3>
              <p className="text-gray-500">
                Select an email draft from the list or generate new emails from student detail
                views.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
