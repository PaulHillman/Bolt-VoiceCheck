import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: false
  },
  global: {
    headers: {
      'x-cache-bust': Date.now().toString()
    }
  }
});

export interface Student {
  id: string;
  name: string;
  email: string;
  section: string | null;
  first_flagged_date: string | null;
  total_warnings: number;
  created_at: string;
  updated_at: string;
}

export interface Discussion {
  id: string;
  title: string;
  section: string | null;
  discussion_date: string | null;
  created_at: string;
}

export interface Submission {
  id: string;
  student_id: string;
  discussion_id: string;
  post_text: string;
  post_timestamp: string | null;
  response_score: number | null;
  created_at: string;
}

export interface AnalysisResult {
  id: string;
  submission_id: string;
  authenticity_score: number;
  red_flags: string[];
  explanation: string;
  analyzed_at: string;
  created_at: string;
}

export interface Warning {
  id: string;
  student_id: string;
  submission_id: string;
  warning_number: number;
  sent_date: string;
  email_content: string;
  created_at: string;
}

export interface EmailTemplate {
  id: string;
  warning_level: number;
  subject: string;
  body_template: string;
  created_at: string;
  updated_at: string;
}

export interface Settings {
  id: string;
  key: string;
  value: any;
  updated_at: string;
}

export interface EmailLog {
  id: string;
  student_id: string;
  submission_id: string | null;
  recipient_email: string;
  cc_emails: string[];
  subject: string;
  body: string;
  warning_number: number;
  resend_message_id: string | null;
  sent_at: string;
  created_at: string;
}
