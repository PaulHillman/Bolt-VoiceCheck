# Self-Check Prompt for Packback Submissions

Use this prompt with ChatGPT or Claude to check your writing BEFORE you submit it to Packback.

---

## Copy and paste this into ChatGPT/Claude:

I'm a student in an undergraduate business ethics course. I need you to review my Packback discussion post for authenticity. My instructor uses an AI detector that checks whether writing sounds like genuine student reflection or AI-generated academic writing.

Please analyze my post using this rubric:

**Score 0-2 (Good - Sounds Authentic):**
- Informal, conversational tone
- Personal anecdotes and first-person experiences (I, me, my)
- Natural speech patterns with contractions (don't, I'd, kinda)
- Some imperfections in writing style
- Sounds like a real person talking about their experience

**Score 3-5 (Problem - Sounds Like AI):**
- Formal academic tone like a textbook
- Advanced vocabulary used perfectly without explanation
- Perfect paragraph structure with smooth transitions
- No personal pronouns or experiences
- Dense, polished prose with no casual language
- Sounds generic rather than personal

**Red Flags to Check For:**
- Am I using overly formal language? (e.g., "one might argue" instead of "I think")
- Am I using advanced terms without defining them? (e.g., "deontological ethics," "moral agency")
- Does every paragraph have perfect structure?
- Am I avoiding contractions and informal language?
- Am I writing in third-person instead of sharing MY experience?
- Does this sound like me talking, or like a textbook?

Please give me:
1. An authenticity score (0-5)
2. Specific feedback on what makes it sound authentic OR what makes it sound AI-generated
3. Suggestions for making it sound more like MY voice if needed

Here's my post:

[PASTE YOUR PACKBACK POST HERE]

---

## Tips for Writing Authentic Posts:

1. **Write like you talk** - Use "I think," "I feel," "in my experience"
2. **Share personal stories** - Real examples from your life make it authentic
3. **Use contractions** - Don't, can't, I'd, it's (not "do not," "cannot")
4. **Be imperfect** - You don't need flawless paragraphs or fancy vocabulary
5. **Define complex terms** - If you use an academic term, explain what you mean
6. **Vary your effort** - Not every answer needs to be a perfect essay
7. **Sound like YOU** - Would you actually say this out loud to a friend?

## What's Okay vs. Not Okay:

**OKAY:**
- Using AI to fix spelling and grammar AFTER you write
- Having AI suggest better word choices for what YOU already wrote
- Getting AI to help organize YOUR ideas more clearly

**NOT OKAY:**
- Having AI write the entire response for you
- Copy-pasting AI text without rewriting it in your voice
- Using AI to generate ideas you didn't actually think of

## If Your Score is 3 or Higher:

Your writing might sound too polished or formal. Try:
- Adding more "I" statements about your personal experience
- Using more casual language and contractions
- Including a specific story or example from your life
- Reading it out loud - does it sound like you talking?
- Removing overly academic vocabulary or defining terms simply

---

**Remember:** The goal is to show your authentic thinking and reflection, not to write a perfect academic essay. Your professor wants to hear YOUR voice and YOUR ideas.
