import { useState, useEffect } from 'react';
import { LoginSplash } from './components/LoginSplash';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { UploadView } from './components/UploadView';
import { StudentDetailView } from './components/StudentDetailView';
import { EmailsView } from './components/EmailsView';
import { EmailLogsView } from './components/EmailLogsView';
import { SettingsView } from './components/SettingsView';
import { QuickAnalysis } from './components/QuickAnalysis';
import { generateEmailContent } from './services/emailGeneration';
import { supabase } from './lib/supabase';
import { checkDatabaseHealth } from './services/healthCheck';

type View = 'dashboard' | 'upload' | 'emails' | 'email-logs' | 'settings' | 'student-detail' | 'quick-analysis';
type UserType = 'admin' | 'student' | 'analyst' | null;

export interface EmailDraft {
  studentId: string;
  submissionId: string;
  studentName: string;
  studentEmail: string;
  warningNumber: number;
  subject: string;
  body: string;
}

function App() {
  const [userType, setUserType] = useState<UserType>(null);
  const [studentGNumber, setStudentGNumber] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [emailDrafts, setEmailDrafts] = useState<EmailDraft[]>([]);
  const [studentData, setStudentData] = useState<any>(null);
  const [databaseHealthy, setDatabaseHealthy] = useState<boolean | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);

  useEffect(() => {
    async function runHealthCheck() {
      const result = await checkDatabaseHealth();
      setDatabaseHealthy(result.isHealthy);
      if (!result.isHealthy) {
        setHealthError(result.error || 'Database is unavailable');
      }
    }
    runHealthCheck();
  }, []);

  function handleViewStudent(studentId: string) {
    setSelectedStudentId(studentId);
    setCurrentView('student-detail');
  }

  function handleBackToDashboard() {
    setSelectedStudentId(null);
    setCurrentView('dashboard');
  }

  async function handleGenerateEmail(studentId: string, submissionId: string) {
    try {
      const { subject, body, warningNumber } = await generateEmailContent(studentId, submissionId);

      const { data: student } = await supabase
        .from('students')
        .select('name, email')
        .eq('id', studentId)
        .single();

      if (!student) throw new Error('Student not found');

      const newDraft: EmailDraft = {
        studentId,
        submissionId,
        studentName: student.name,
        studentEmail: student.email,
        warningNumber,
        subject,
        body,
      };

      setEmailDrafts((prev) => {
        const filtered = prev.filter(d => d.submissionId !== submissionId);
        return [...filtered, newDraft];
      });

      setCurrentView('emails');
    } catch (error) {
      console.error('Error generating email:', error);
      alert('Failed to generate email. Please try again.');
    }
  }

  function handleNavigate(view: string) {
    setCurrentView(view as View);
    if (view !== 'student-detail') {
      setSelectedStudentId(null);
    }
  }

  function handleRemoveDraft(submissionId: string) {
    setEmailDrafts((prev) => prev.filter(d => d.submissionId !== submissionId));
  }

  function handleAdminLogin() {
    setUserType('admin');
    setSelectedStudentId(null);
    setCurrentView('dashboard');
  }

  function handleAnalystLogin() {
    setUserType('analyst');
    setCurrentView('quick-analysis');
  }

  async function handleStudentLogin(gNumber: string) {
    try {
      const { data: student, error } = await supabase
        .from('students')
        .select('*')
        .eq('g_number', gNumber)
        .maybeSingle();

      if (error) throw error;

      if (!student) {
        alert('Student not found. Please check your G-number and try again.');
        return;
      }

      setUserType('student');
      setStudentGNumber(gNumber);
      setStudentData(student);
      setSelectedStudentId(student.id);
    } catch (error) {
      console.error('Error logging in:', error);
      alert('An error occurred during login. Please try again.');
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    setUserType(null);
    setStudentGNumber(null);
    setStudentData(null);
    setSelectedStudentId(null);
    setCurrentView('dashboard');
  }

  if (databaseHealthy === null) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking database connection...</p>
        </div>
      </div>
    );
  }

  if (databaseHealthy === false) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
          <div className="text-center mb-6">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
              <svg className="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Database Unavailable</h2>
            <p className="text-gray-600 mb-4">{healthError}</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-gray-900 mb-2">Possible causes:</h3>
            <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
              <li>Database has been paused or suspended</li>
              <li>Network connectivity issues</li>
              <li>Database maintenance in progress</li>
            </ul>
          </div>
          <div className="space-y-3">
            <button
              onClick={() => window.location.reload()}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Retry Connection
            </button>
            <a
              href="https://supabase.com/dashboard/project/lnaquzxwvnjycrmvkayt"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-center"
            >
              Open Supabase Dashboard
            </a>
          </div>
        </div>
      </div>
    );
  }

  if (!userType) {
    return (
      <LoginSplash
        onAdminLogin={handleAdminLogin}
        onStudentLogin={handleStudentLogin}
        onAnalystLogin={handleAnalystLogin}
      />
    );
  }

  if (userType === 'student' && selectedStudentId) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center space-x-4">
                <img
                  src="/VoiceCheck_Logo.png"
                  alt="VoiceCheck"
                  className="h-16 w-auto object-contain"
                />
                <div className="border-l border-gray-300 pl-4">
                  <p className="text-sm text-gray-600">Student Portal</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
        <main>
          <StudentDetailView
            studentId={selectedStudentId}
            onBack={handleLogout}
            viewMode="student"
          />
        </main>
      </div>
    );
  }

  if (userType === 'analyst') {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center space-x-4">
                <img
                  src="/VoiceCheck_Logo.png"
                  alt="VoiceCheck"
                  className="h-16 w-auto object-contain"
                />
                <div className="border-l border-gray-300 pl-4">
                  <p className="text-sm text-gray-600">Analyst Portal</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
        <main>
          <QuickAnalysis />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onNavigate={handleNavigate} currentView={currentView} onLogout={handleLogout} />

      <main>
        {currentView === 'dashboard' && (
          <Dashboard onViewStudent={handleViewStudent} />
        )}

        {currentView === 'upload' && <UploadView />}

        {currentView === 'student-detail' && selectedStudentId && (
          <StudentDetailView
            studentId={selectedStudentId}
            onBack={handleBackToDashboard}
            viewMode="admin"
            onGenerateEmail={handleGenerateEmail}
          />
        )}

        {currentView === 'emails' && (
          <EmailsView
            drafts={emailDrafts}
            onRemoveDraft={handleRemoveDraft}
          />
        )}

        {currentView === 'email-logs' && <EmailLogsView />}

        {currentView === 'settings' && <SettingsView />}

        {currentView === 'quick-analysis' && <QuickAnalysis />}
      </main>
    </div>
  );
}

export default App;
