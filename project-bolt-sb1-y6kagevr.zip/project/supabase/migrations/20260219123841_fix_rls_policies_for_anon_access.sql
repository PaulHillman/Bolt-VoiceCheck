/*
  # Fix RLS Policies for Anonymous Access

  Since the app doesn't use authentication, we need to allow anonymous (anon) role access to all tables.

  ## Changes
  1. Drop all existing policies that require `authenticated` role
  2. Create new policies that allow `anon` role full access to all tables
*/

-- Drop existing authenticated policies for students table
DROP POLICY IF EXISTS "Authenticated users can view students" ON students;
DROP POLICY IF EXISTS "Authenticated users can insert students" ON students;
DROP POLICY IF EXISTS "Authenticated users can update students" ON students;
DROP POLICY IF EXISTS "Authenticated users can delete students" ON students;

-- Drop existing authenticated policies for discussions table
DROP POLICY IF EXISTS "Authenticated users can view discussions" ON discussions;
DROP POLICY IF EXISTS "Authenticated users can insert discussions" ON discussions;
DROP POLICY IF EXISTS "Authenticated users can update discussions" ON discussions;
DROP POLICY IF EXISTS "Authenticated users can delete discussions" ON discussions;

-- Drop existing authenticated policies for submissions table
DROP POLICY IF EXISTS "Authenticated users can view submissions" ON submissions;
DROP POLICY IF EXISTS "Authenticated users can insert submissions" ON submissions;
DROP POLICY IF EXISTS "Authenticated users can update submissions" ON submissions;
DROP POLICY IF EXISTS "Authenticated users can delete submissions" ON submissions;

-- Drop existing authenticated policies for analysis_results table
DROP POLICY IF EXISTS "Authenticated users can view analysis results" ON analysis_results;
DROP POLICY IF EXISTS "Authenticated users can insert analysis results" ON analysis_results;
DROP POLICY IF EXISTS "Authenticated users can update analysis results" ON analysis_results;
DROP POLICY IF EXISTS "Authenticated users can delete analysis results" ON analysis_results;

-- Drop existing authenticated policies for warnings table
DROP POLICY IF EXISTS "Authenticated users can view warnings" ON warnings;
DROP POLICY IF EXISTS "Authenticated users can insert warnings" ON warnings;
DROP POLICY IF EXISTS "Authenticated users can update warnings" ON warnings;
DROP POLICY IF EXISTS "Authenticated users can delete warnings" ON warnings;

-- Drop existing authenticated policies for email_templates table
DROP POLICY IF EXISTS "Authenticated users can view email templates" ON email_templates;
DROP POLICY IF EXISTS "Authenticated users can insert email templates" ON email_templates;
DROP POLICY IF EXISTS "Authenticated users can update email templates" ON email_templates;
DROP POLICY IF EXISTS "Authenticated users can delete email templates" ON email_templates;

-- Drop existing authenticated policies for settings table
DROP POLICY IF EXISTS "Authenticated users can view settings" ON settings;
DROP POLICY IF EXISTS "Authenticated users can insert settings" ON settings;
DROP POLICY IF EXISTS "Authenticated users can update settings" ON settings;
DROP POLICY IF EXISTS "Authenticated users can delete settings" ON settings;

-- Create new policies for anonymous access

-- Students table policies
CREATE POLICY "Anonymous users can view students"
  ON students FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert students"
  ON students FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update students"
  ON students FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete students"
  ON students FOR DELETE
  TO anon
  USING (true);

-- Discussions table policies
CREATE POLICY "Anonymous users can view discussions"
  ON discussions FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert discussions"
  ON discussions FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update discussions"
  ON discussions FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete discussions"
  ON discussions FOR DELETE
  TO anon
  USING (true);

-- Submissions table policies
CREATE POLICY "Anonymous users can view submissions"
  ON submissions FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert submissions"
  ON submissions FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update submissions"
  ON submissions FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete submissions"
  ON submissions FOR DELETE
  TO anon
  USING (true);

-- Analysis results table policies
CREATE POLICY "Anonymous users can view analysis results"
  ON analysis_results FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert analysis results"
  ON analysis_results FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update analysis results"
  ON analysis_results FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete analysis results"
  ON analysis_results FOR DELETE
  TO anon
  USING (true);

-- Warnings table policies
CREATE POLICY "Anonymous users can view warnings"
  ON warnings FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert warnings"
  ON warnings FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update warnings"
  ON warnings FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete warnings"
  ON warnings FOR DELETE
  TO anon
  USING (true);

-- Email templates table policies
CREATE POLICY "Anonymous users can view email templates"
  ON email_templates FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert email templates"
  ON email_templates FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update email templates"
  ON email_templates FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete email templates"
  ON email_templates FOR DELETE
  TO anon
  USING (true);

-- Settings table policies
CREATE POLICY "Anonymous users can view settings"
  ON settings FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anonymous users can insert settings"
  ON settings FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anonymous users can update settings"
  ON settings FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anonymous users can delete settings"
  ON settings FOR DELETE
  TO anon
  USING (true);
