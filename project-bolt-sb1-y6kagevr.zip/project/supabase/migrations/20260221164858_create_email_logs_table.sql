/*
  # Create email logs table

  1. New Tables
    - `email_logs`
      - `id` (uuid, primary key) - Unique identifier for each email log
      - `student_id` (uuid, foreign key) - References the student who received the email
      - `submission_id` (uuid, foreign key) - References the submission that triggered the email
      - `recipient_email` (text) - Email address of the recipient
      - `cc_emails` (text[]) - Array of CC'd email addresses
      - `subject` (text) - Email subject line
      - `body` (text) - Full email body content
      - `warning_number` (integer) - Which warning number this was (1, 2, 3, etc.)
      - `resend_message_id` (text) - Message ID from Resend API for tracking
      - `sent_at` (timestamptz) - Timestamp when email was sent
      - `created_at` (timestamptz) - Record creation timestamp

  2. Security
    - Enable RLS on `email_logs` table
    - Add policy for authenticated users to read all email logs (professors need to see all sent emails)

  3. Indexes
    - Index on student_id for quick lookup of all emails sent to a student
    - Index on sent_at for chronological queries
*/

CREATE TABLE IF NOT EXISTS email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  submission_id uuid REFERENCES submissions(id) ON DELETE SET NULL,
  recipient_email text NOT NULL,
  cc_emails text[] DEFAULT ARRAY['HillmanP@gvsu.edu'],
  subject text NOT NULL,
  body text NOT NULL,
  warning_number integer NOT NULL,
  resend_message_id text,
  sent_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all email logs"
  ON email_logs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anonymous users can view all email logs"
  ON email_logs
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Authenticated users can insert email logs"
  ON email_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anonymous users can insert email logs"
  ON email_logs
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_email_logs_student_id ON email_logs(student_id);
CREATE INDEX IF NOT EXISTS idx_email_logs_sent_at ON email_logs(sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_email_logs_warning_number ON email_logs(warning_number);
