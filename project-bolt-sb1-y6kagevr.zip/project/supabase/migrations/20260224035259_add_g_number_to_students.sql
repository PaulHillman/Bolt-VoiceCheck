/*
  # Add G-number field to students table

  1. Changes
    - Add `g_number` column to students table (unique, indexed)
    - Make it the primary identifier for student login
  
  2. Notes
    - G-numbers are unique identifiers like "G02557747"
    - This will be used for student authentication
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'students' AND column_name = 'g_number'
  ) THEN
    ALTER TABLE students ADD COLUMN g_number text UNIQUE;
    CREATE INDEX IF NOT EXISTS idx_students_g_number ON students(g_number);
  END IF;
END $$;
