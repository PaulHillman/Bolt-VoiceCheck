/*
  # Add INSERT policy for student_logins table

  1. Changes
    - Add INSERT policy to allow anonymous users to record their logins
    - This enables tracking when students log in to view their submissions

  2. Security
    - Policy allows anyone to insert login records
    - This is safe as it only records G-numbers and timestamps
    - No sensitive data exposure risk
*/

-- Add INSERT policy for student logins
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'student_logins' 
    AND policyname = 'Anyone can insert login records'
    AND cmd = 'INSERT'
  ) THEN
    CREATE POLICY "Anyone can insert login records"
      ON student_logins
      FOR INSERT
      TO anon
      WITH CHECK (true);
  END IF;
END $$;
