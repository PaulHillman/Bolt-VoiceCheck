/*
  # Fix Students RLS for Anonymous Read Access
  
  1. Changes
    - Drop conflicting RLS policies on students table
    - Create single clear policy for anonymous read access
    - Maintain student-specific read policy with proper precedence
    
  2. Security
    - Anonymous users can read all students (needed for admin dashboard)
    - Students can still read their own record via g_number header
*/

-- Drop existing conflicting policies
DROP POLICY IF EXISTS "Anonymous users can view students" ON students;
DROP POLICY IF EXISTS "Students can read own record via g_number" ON students;

-- Create clean policy for anonymous read access
CREATE POLICY "Allow anonymous read access to students"
  ON students
  FOR SELECT
  TO anon
  USING (true);
