/*
  # Add submission type field to differentiate questions from responses

  ## Changes
  1. Schema Changes
    - Add `submission_type` column to submissions table with values 'question' or 'response'
    - Default to 'response' for backward compatibility
    - Add check constraint to ensure valid values

  2. Notes
    - Existing records will be marked as 'response' by default
    - New submissions can specify whether they are questions or responses
    - This allows different analysis thresholds for questions vs responses
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'submissions' AND column_name = 'submission_type'
  ) THEN
    ALTER TABLE submissions ADD COLUMN submission_type text DEFAULT 'response' CHECK (submission_type IN ('question', 'response'));
  END IF;
END $$;