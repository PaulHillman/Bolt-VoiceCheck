/*
  # Add Insert Policy for Discussions Table

  1. Changes
    - Add INSERT policy for discussions table to allow anonymous users to create new discussions
    - This is needed when uploading submissions that reference new discussion topics
  
  2. Security
    - Policy allows anonymous users to insert new discussion records
    - This is safe because discussions are just metadata about Packback discussion topics
*/

-- Drop existing policy if it exists and recreate
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'discussions' 
    AND policyname = 'Anonymous users can create discussions'
  ) THEN
    DROP POLICY "Anonymous users can create discussions" ON discussions;
  END IF;
END $$;

-- Create insert policy for discussions
CREATE POLICY "Anonymous users can create discussions"
  ON discussions
  FOR INSERT
  TO anon
  WITH CHECK (true);
