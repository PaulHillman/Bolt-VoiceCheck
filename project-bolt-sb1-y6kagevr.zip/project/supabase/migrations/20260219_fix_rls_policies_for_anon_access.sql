-- Migration: Fix RLS policies for anonymous access
-- Since the app doesn't use authentication, we need to allow anon role access to all tables

-- Drop all existing policies that require authenticated role
DROP POLICY IF EXISTS "Students are viewable by authenticated users" ON students;
DROP POLICY IF EXISTS "Students can be inserted by authenticated users" ON students;
DROP POLICY IF EXISTS "Students can be updated by authenticated users" ON students;
DROP POLICY IF EXISTS "Students can be deleted by authenticated users" ON students;

DROP POLICY IF EXISTS "Discussions are viewable by authenticated users" ON discussions;
DROP POLICY IF EXISTS "Discussions can be inserted by authenticated users" ON discussions;
DROP POLICY IF EXISTS "Discussions can be updated by authenticated users" ON discussions;
DROP POLICY IF EXISTS "Discussions can be deleted by authenticated users" ON discussions;

DROP POLICY IF EXISTS "Submissions are viewable by authenticated users" ON submissions;
DROP POLICY IF EXISTS "Submissions can be inserted by authenticated users" ON submissions;
DROP POLICY IF EXISTS "Submissions can be updated by authenticated users" ON submissions;
DROP POLICY IF EXISTS "Submissions can be deleted by authenticated users" ON submissions;

DROP POLICY IF EXISTS "Analysis results are viewable by authenticated users" ON analysis_results;
DROP POLICY IF EXISTS "Analysis results can be inserted by authenticated users" ON analysis_results;
DROP POLICY IF EXISTS "Analysis results can be updated by authenticated users" ON analysis_results;
DROP POLICY IF EXISTS "Analysis results can be deleted by authenticated users" ON analysis_results;

DROP POLICY IF EXISTS "Warnings are viewable by authenticated users" ON warnings;
DROP POLICY IF EXISTS "Warnings can be inserted by authenticated users" ON warnings;
DROP POLICY IF EXISTS "Warnings can be updated by authenticated users" ON warnings;
DROP POLICY IF EXISTS "Warnings can be deleted by authenticated users" ON warnings;

DROP POLICY IF EXISTS "Email templates are viewable by authenticated users" ON email_templates;
DROP POLICY IF EXISTS "Email templates can be inserted by authenticated users" ON email_templates;
DROP POLICY IF EXISTS "Email templates can be updated by authenticated users" ON email_templates;
DROP POLICY IF EXISTS "Email templates can be deleted by authenticated users" ON email_templates;

DROP POLICY IF EXISTS "Settings are viewable by authenticated users" ON settings;
DROP POLICY IF EXISTS "Settings can be inserted by authenticated users" ON settings;
DROP POLICY IF EXISTS "Settings can be updated by authenticated users" ON settings;
DROP POLICY IF EXISTS "Settings can be deleted by authenticated users" ON settings;

-- Create new policies that allow anon role access

-- Students table policies
CREATE POLICY "Students are viewable by anon users"
  ON students FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Students can be inserted by anon users"
  ON students FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Students can be updated by anon users"
  ON students FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Students can be deleted by anon users"
  ON students FOR DELETE
  TO anon
  USING (true);

-- Discussions table policies
CREATE POLICY "Discussions are viewable by anon users"
  ON discussions FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Discussions can be inserted by anon users"
  ON discussions FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Discussions can be updated by anon users"
  ON discussions FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Discussions can be deleted by anon users"
  ON discussions FOR DELETE
  TO anon
  USING (true);

-- Submissions table policies
CREATE POLICY "Submissions are viewable by anon users"
  ON submissions FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Submissions can be inserted by anon users"
  ON submissions FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Submissions can be updated by anon users"
  ON submissions FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Submissions can be deleted by anon users"
  ON submissions FOR DELETE
  TO anon
  USING (true);

-- Analysis results table policies
CREATE POLICY "Analysis results are viewable by anon users"
  ON analysis_results FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Analysis results can be inserted by anon users"
  ON analysis_results FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Analysis results can be updated by anon users"
  ON analysis_results FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Analysis results can be deleted by anon users"
  ON analysis_results FOR DELETE
  TO anon
  USING (true);

-- Warnings table policies
CREATE POLICY "Warnings are viewable by anon users"
  ON warnings FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Warnings can be inserted by anon users"
  ON warnings FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Warnings can be updated by anon users"
  ON warnings FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Warnings can be deleted by anon users"
  ON warnings FOR DELETE
  TO anon
  USING (true);

-- Email templates table policies
CREATE POLICY "Email templates are viewable by anon users"
  ON email_templates FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Email templates can be inserted by anon users"
  ON email_templates FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Email templates can be updated by anon users"
  ON email_templates FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Email templates can be deleted by anon users"
  ON email_templates FOR DELETE
  TO anon
  USING (true);

-- Settings table policies
CREATE POLICY "Settings are viewable by anon users"
  ON settings FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Settings can be inserted by anon users"
  ON settings FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Settings can be updated by anon users"
  ON settings FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Settings can be deleted by anon users"
  ON settings FOR DELETE
  TO anon
  USING (true);
