/*
  # Fix Security Issues - Comprehensive Update

  ## Changes Made
  
  1. **Index Optimization**
     - Add missing index on `email_logs.student_id` (foreign key)
     - Remove unused indexes that are not being utilized by queries
  
  2. **RLS Policy Fixes**
     - Remove overly permissive policies that allow unrestricted access
     - All tables now properly secured with RLS enabled but no blanket access
     - Anonymous users have NO direct write access to any tables
     - Only edge functions (via service role) should write to these tables
  
  ## Security Model
  
  The application uses edge functions with service role keys for all writes.
  Anonymous users can only READ data, not INSERT/UPDATE/DELETE.
  This prevents unauthorized data manipulation while maintaining functionality.
  
  ## Tables Affected
  
  - `analysis_results` - Read-only for anon
  - `discussions` - Read-only for anon
  - `email_logs` - Read-only for anon/authenticated
  - `email_templates` - Read-only for anon
  - `settings` - Read-only for anon
  - `student_logins` - No anon access (only edge functions)
  - `students` - Read-only for anon, students can read own record
  - `submissions` - Read-only for anon, students can read own submissions
  - `warnings` - Read-only for anon
*/

-- =====================================================
-- STEP 1: Add Missing Index for Foreign Key
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_email_logs_student_id 
  ON email_logs(student_id);

-- =====================================================
-- STEP 2: Remove Unused Indexes
-- =====================================================

DROP INDEX IF EXISTS idx_email_logs_submission_id;
DROP INDEX IF EXISTS idx_warnings_submission_id;
DROP INDEX IF EXISTS idx_student_logins_logged_in_at;

-- =====================================================
-- STEP 3: Fix RLS Policies - Remove Overly Permissive Policies
-- =====================================================

-- analysis_results: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert analysis results" ON analysis_results;
DROP POLICY IF EXISTS "Anonymous users can update analysis results" ON analysis_results;

-- discussions: Remove unrestricted INSERT for anon
DROP POLICY IF EXISTS "Anonymous users can insert discussions" ON discussions;

-- email_logs: Remove unrestricted INSERT for anon and authenticated
DROP POLICY IF EXISTS "Anonymous users can insert email logs" ON email_logs;
DROP POLICY IF EXISTS "Authenticated users can insert email logs" ON email_logs;

-- email_templates: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert email templates" ON email_templates;
DROP POLICY IF EXISTS "Anonymous users can update email templates" ON email_templates;

-- settings: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert settings" ON settings;
DROP POLICY IF EXISTS "Anonymous users can update settings" ON settings;

-- student_logins: Remove unrestricted INSERT for anon
DROP POLICY IF EXISTS "Anyone can insert login records" ON student_logins;

-- students: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert students" ON students;
DROP POLICY IF EXISTS "Anonymous users can update students" ON students;

-- submissions: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert submissions" ON submissions;
DROP POLICY IF EXISTS "Anonymous users can update submissions" ON submissions;

-- warnings: Remove unrestricted INSERT/UPDATE for anon
DROP POLICY IF EXISTS "Anonymous users can insert warnings" ON warnings;
DROP POLICY IF EXISTS "Anonymous users can update warnings" ON warnings;

-- =====================================================
-- STEP 4: Add Proper RLS Policies (Read-Only for Anon)
-- =====================================================

-- Students: Allow students to read their own record via G-number
CREATE POLICY "Students can read own record via g_number"
  ON students
  FOR SELECT
  TO anon
  USING (
    g_number IS NOT NULL AND 
    g_number = current_setting('request.headers', true)::json->>'x-student-g-number'
  );

-- Submissions: Allow students to read their own submissions
CREATE POLICY "Students can read own submissions"
  ON submissions
  FOR SELECT
  TO anon
  USING (
    student_id IN (
      SELECT id FROM students 
      WHERE g_number = current_setting('request.headers', true)::json->>'x-student-g-number'
    )
  );

-- Analysis Results: Allow students to read analysis for their submissions
CREATE POLICY "Students can read own analysis results"
  ON analysis_results
  FOR SELECT
  TO anon
  USING (
    submission_id IN (
      SELECT s.id FROM submissions s
      INNER JOIN students st ON s.student_id = st.id
      WHERE st.g_number = current_setting('request.headers', true)::json->>'x-student-g-number'
    )
  );

-- Warnings: Allow students to read their own warnings
CREATE POLICY "Students can read own warnings"
  ON warnings
  FOR SELECT
  TO anon
  USING (
    student_id IN (
      SELECT id FROM students 
      WHERE g_number = current_setting('request.headers', true)::json->>'x-student-g-number'
    )
  );

-- Discussions: Keep existing SELECT policy (anon can read all)
-- Email Templates: Keep existing SELECT policy (anon can read all)
-- Settings: Keep existing SELECT policy (anon can read all)
-- Email Logs: Keep existing SELECT policies (anon/authenticated can read all)

-- =====================================================
-- NOTES
-- =====================================================

/*
  Auth DB Connection Strategy Warning:
  The warning about Auth DB connection strategy requires configuration changes
  in the Supabase dashboard and cannot be fixed via SQL migration.
  
  To fix: Go to Supabase Dashboard > Settings > Database > Connection Pooling
  and change the Auth server configuration to use percentage-based allocation.
  
  All write operations (INSERT/UPDATE/DELETE) should now go through edge functions
  using the service role key, which bypasses RLS. This provides proper security
  while maintaining necessary functionality.
*/