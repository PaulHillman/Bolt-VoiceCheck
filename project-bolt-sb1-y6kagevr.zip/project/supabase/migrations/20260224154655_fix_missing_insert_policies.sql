/*
  # Fix Missing INSERT Policies for Upload Flow

  1. Changes
    - Add INSERT policy for `students` table to allow anonymous users to create student records
    - Add INSERT policy for `submissions` table to allow anonymous users to create submissions
    - Add INSERT policy for `analysis_results` table to allow anonymous users to create analysis results
    - Add UPDATE policy for `students` table to allow updating first_flagged_date
  
  2. Security
    - These policies allow the admin upload flow to work
    - Anonymous users represent the admin in this application context
    - RLS remains enabled on all tables
*/

-- Drop existing policies if they exist to avoid conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anonymous users can create students" ON students;
  DROP POLICY IF EXISTS "Anonymous users can update students" ON students;
  DROP POLICY IF EXISTS "Anonymous users can create submissions" ON submissions;
  DROP POLICY IF EXISTS "Anonymous users can create analysis results" ON analysis_results;
  DROP POLICY IF EXISTS "Anonymous users can update analysis results" ON analysis_results;
END $$;

-- Allow anonymous users to insert students
CREATE POLICY "Anonymous users can create students"
  ON students
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anonymous users to update students (for first_flagged_date)
CREATE POLICY "Anonymous users can update students"
  ON students
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

-- Allow anonymous users to insert submissions
CREATE POLICY "Anonymous users can create submissions"
  ON submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anonymous users to insert analysis results
CREATE POLICY "Anonymous users can create analysis results"
  ON analysis_results
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anonymous users to update analysis results
CREATE POLICY "Anonymous users can update analysis results"
  ON analysis_results
  FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);
