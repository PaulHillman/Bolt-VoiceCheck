/*
  # Fix email_logs table to allow test emails without students

  1. Changes
    - Make student_id nullable to allow logging of test emails
    - This enables logging emails sent for testing purposes without requiring a student record
  
  2. Security
    - No RLS changes needed - policies already in place
*/

ALTER TABLE email_logs 
ALTER COLUMN student_id DROP NOT NULL;
