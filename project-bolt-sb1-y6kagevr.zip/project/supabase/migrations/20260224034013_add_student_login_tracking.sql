/*
  # Add Student Login Tracking

  1. New Tables
    - `student_logins`
      - `id` (uuid, primary key)
      - `g_number` (text) - Student G number
      - `student_name` (text) - Student name for easy reference
      - `logged_in_at` (timestamptz) - Timestamp of login
      - `created_at` (timestamptz) - Record creation time

  2. Security
    - Enable RLS on `student_logins` table
    - Add policy for anonymous users to insert their own login records
    - Add policy for anonymous users to read their own login records
    - No authentication required since this is a student portal

  3. Indexes
    - Add index on g_number for fast lookups
    - Add index on logged_in_at for sorting
*/

CREATE TABLE IF NOT EXISTS student_logins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  g_number text NOT NULL,
  student_name text NOT NULL,
  logged_in_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_student_logins_g_number ON student_logins(g_number);
CREATE INDEX IF NOT EXISTS idx_student_logins_logged_in_at ON student_logins(logged_in_at DESC);

-- Enable RLS
ALTER TABLE student_logins ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert login records (student portal is open access)
CREATE POLICY "Anyone can insert login records"
  ON student_logins
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Allow anyone to read login records (instructor needs to see all)
CREATE POLICY "Anyone can read login records"
  ON student_logins
  FOR SELECT
  TO anon
  USING (true);