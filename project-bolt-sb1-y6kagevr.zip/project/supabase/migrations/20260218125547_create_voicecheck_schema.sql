/*
  # VoiceCheck Database Schema

  ## Overview
  This migration creates the complete database schema for VoiceCheck, a system for detecting
  AI-overused submissions in Packback discussions and tracking student warning history.

  ## New Tables

  ### 1. students
  Stores student information and warning counts
  - `id` (uuid, primary key) - Unique student identifier
  - `name` (text) - Student full name
  - `email` (text, unique) - Student email address
  - `section` (text) - Class section identifier
  - `first_flagged_date` (timestamptz) - Date of first flagged submission
  - `total_warnings` (integer) - Total number of warnings sent
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. discussions
  Stores discussion questions and metadata
  - `id` (uuid, primary key) - Unique discussion identifier
  - `title` (text) - Discussion question or title
  - `section` (text) - Class section
  - `discussion_date` (date) - Date of discussion
  - `created_at` (timestamptz) - Record creation timestamp

  ### 3. submissions
  Stores student posts with full text
  - `id` (uuid, primary key) - Unique submission identifier
  - `student_id` (uuid, foreign key) - Reference to students table
  - `discussion_id` (uuid, foreign key) - Reference to discussions table
  - `post_text` (text) - Full submission text
  - `post_timestamp` (timestamptz) - When student submitted
  - `response_score` (integer) - Packback response score
  - `created_at` (timestamptz) - Record creation timestamp

  ### 4. analysis_results
  Stores AI authenticity analysis results
  - `id` (uuid, primary key) - Unique analysis identifier
  - `submission_id` (uuid, foreign key) - Reference to submissions table
  - `authenticity_score` (integer) - Score 0-5 (0=authentic, 5=AI-heavy)
  - `red_flags` (text array) - List of detected issues
  - `explanation` (text) - Detailed explanation of score
  - `analyzed_at` (timestamptz) - When analysis was performed
  - `created_at` (timestamptz) - Record creation timestamp

  ### 5. warnings
  Tracks each warning sent to students
  - `id` (uuid, primary key) - Unique warning identifier
  - `student_id` (uuid, foreign key) - Reference to students table
  - `submission_id` (uuid, foreign key) - Reference to submissions table
  - `warning_number` (integer) - Which warning this is (1, 2, 3, etc.)
  - `sent_date` (timestamptz) - When warning was sent
  - `email_content` (text) - Full email content sent
  - `created_at` (timestamptz) - Record creation timestamp

  ### 6. email_templates
  Stores email templates for different warning levels
  - `id` (uuid, primary key) - Unique template identifier
  - `warning_level` (integer) - Which warning number (1, 2, 3, 4+)
  - `subject` (text) - Email subject line
  - `body_template` (text) - Email body with placeholders
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 7. settings
  Stores application configuration
  - `id` (uuid, primary key) - Unique setting identifier
  - `key` (text, unique) - Setting key
  - `value` (jsonb) - Setting value
  - `updated_at` (timestamptz) - Last update timestamp

  ## Security
  - RLS enabled on all tables
  - Policies created for authenticated users to manage all data
  - Restrictive by default, only authenticated users have access

  ## Indexes
  - Index on students.email for quick lookups
  - Index on submissions.student_id for efficient queries
  - Index on warnings.student_id and sent_date for warning history
  - Index on analysis_results.submission_id for joining data
*/

-- Create students table
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  section text,
  first_flagged_date timestamptz,
  total_warnings integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create discussions table
CREATE TABLE IF NOT EXISTS discussions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  section text,
  discussion_date date,
  created_at timestamptz DEFAULT now()
);

-- Create submissions table
CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  discussion_id uuid NOT NULL REFERENCES discussions(id) ON DELETE CASCADE,
  post_text text NOT NULL,
  post_timestamp timestamptz,
  response_score integer,
  created_at timestamptz DEFAULT now()
);

-- Create analysis_results table
CREATE TABLE IF NOT EXISTS analysis_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  authenticity_score integer NOT NULL CHECK (authenticity_score >= 0 AND authenticity_score <= 5),
  red_flags text[],
  explanation text,
  analyzed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create warnings table
CREATE TABLE IF NOT EXISTS warnings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  submission_id uuid NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  warning_number integer NOT NULL,
  sent_date timestamptz DEFAULT now(),
  email_content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create email_templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warning_level integer NOT NULL UNIQUE,
  subject text NOT NULL,
  body_template text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_students_email ON students(email);
CREATE INDEX IF NOT EXISTS idx_submissions_student_id ON submissions(student_id);
CREATE INDEX IF NOT EXISTS idx_submissions_discussion_id ON submissions(discussion_id);
CREATE INDEX IF NOT EXISTS idx_analysis_submission_id ON analysis_results(submission_id);
CREATE INDEX IF NOT EXISTS idx_warnings_student_id ON warnings(student_id);
CREATE INDEX IF NOT EXISTS idx_warnings_sent_date ON warnings(sent_date);

-- Enable Row Level Security
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE discussions ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE analysis_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE warnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for students table
CREATE POLICY "Authenticated users can view students"
  ON students FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert students"
  ON students FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update students"
  ON students FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete students"
  ON students FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for discussions table
CREATE POLICY "Authenticated users can view discussions"
  ON discussions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert discussions"
  ON discussions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update discussions"
  ON discussions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete discussions"
  ON discussions FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for submissions table
CREATE POLICY "Authenticated users can view submissions"
  ON submissions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert submissions"
  ON submissions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update submissions"
  ON submissions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete submissions"
  ON submissions FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for analysis_results table
CREATE POLICY "Authenticated users can view analysis results"
  ON analysis_results FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert analysis results"
  ON analysis_results FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update analysis results"
  ON analysis_results FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete analysis results"
  ON analysis_results FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for warnings table
CREATE POLICY "Authenticated users can view warnings"
  ON warnings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert warnings"
  ON warnings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update warnings"
  ON warnings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete warnings"
  ON warnings FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for email_templates table
CREATE POLICY "Authenticated users can view email templates"
  ON email_templates FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert email templates"
  ON email_templates FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update email templates"
  ON email_templates FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete email templates"
  ON email_templates FOR DELETE
  TO authenticated
  USING (true);

-- Create RLS policies for settings table
CREATE POLICY "Authenticated users can view settings"
  ON settings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert settings"
  ON settings FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete settings"
  ON settings FOR DELETE
  TO authenticated
  USING (true);

-- Insert default email templates
INSERT INTO email_templates (warning_level, subject, body_template)
VALUES 
  (1, 'Packback Discussion - Writing Authenticity Concern', 
   'Hi {{student_name}},

I wanted to reach out regarding your recent Packback post from {{post_date}} in the discussion "{{discussion_title}}".

After reviewing your submission, I noticed some patterns that suggest the response may have been heavily assisted by AI tools. Specifically:

{{red_flags}}

Here are some examples from your post:
{{quotes}}

{{explanation}}

For future discussions, I encourage you to:
- Write in your own voice and share your genuine thoughts
- Use conversational language that reflects how you actually speak
- Include personal experiences or examples when relevant
- Avoid overly formal or sophisticated phrasing that doesn''t sound like you

Packback is designed to help you develop critical thinking and authentic communication skills. These are valuable abilities that will serve you well beyond this course.

If you have any questions or would like to discuss this further, please feel free to reach out.

Best,
{{instructor_name}}'),
  
  (2, 'Packback Discussion - Second Writing Authenticity Concern',
   'Hi {{student_name}},

This is the second time I''ve had concerns about the authenticity of your Packback submissions. Your post from {{post_date}} in "{{discussion_title}}" shows similar patterns to your previous flagged submission from {{previous_warning_date}}.

{{red_flags}}

{{explanation}}

I want to emphasize that Packback is about developing YOUR voice and critical thinking skills. Relying on AI tools undermines this learning process and doesn''t accurately reflect your abilities.

Moving forward, I expect to see genuine, personal engagement in your posts. If you''re struggling with the discussions or need guidance on how to write more authentically, please reach out to me or visit office hours.

A third occurrence will require us to meet to discuss this pattern and may impact your grade.

Best,
{{instructor_name}}'),
  
  (3, 'Packback Discussion - Third Writing Authenticity Concern - Meeting Required',
   'Hi {{student_name}},

This is now the third time your Packback submissions have shown evidence of heavy AI assistance. Your post from {{post_date}} continues the pattern I''ve flagged on {{previous_warning_dates}}.

{{explanation}}

At this point, we need to meet to discuss this ongoing issue. This pattern of submissions suggests a fundamental misunderstanding of the purpose of these discussions and raises academic integrity concerns.

Please schedule a meeting with me within the next week. We will discuss:
- The pattern of AI-assisted submissions
- Your understanding of academic integrity policies
- Expectations for future assignments
- Potential grade implications

Continued instances of AI-overused work may result in grade penalties or referral to academic integrity proceedings.

Please respond to confirm you''ve received this message and to schedule our meeting.

{{instructor_name}}'),
  
  (4, 'Packback Discussion - Academic Integrity Violation',
   'Hi {{student_name}},

Despite our previous conversations and warnings on {{previous_warning_dates}}, your submission from {{post_date}} continues to show heavy AI assistance.

This pattern represents a serious academic integrity concern. As a result:

- This submission will receive a zero
- Your overall Packback grade will be impacted
- This matter is being documented and may be referred to the academic integrity office

We must meet immediately to discuss this situation. Please respond within 24 hours to schedule a meeting.

{{instructor_name}}');

-- Insert default settings
INSERT INTO settings (key, value)
VALUES 
  ('score_threshold', '3'),
  ('instructor_name', '{"name": "Instructor Name", "title": "Assistant Professor", "institution": "University Name"}'),
  ('api_key', '{}');
