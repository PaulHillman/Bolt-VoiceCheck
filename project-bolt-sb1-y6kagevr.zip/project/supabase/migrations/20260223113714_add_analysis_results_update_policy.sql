/*
  # Add Update Policy for Analysis Results

  1. Changes Made
    - Add UPDATE policy for `analysis_results` table to allow score editing
    - This policy is required for the score editing feature in student detail view

  2. Security
    - Policy allows anonymous users to update analysis results
    - This is appropriate for this single-user application without authentication
*/

-- Allow updates to analysis_results (needed for score editing)
CREATE POLICY "Anonymous users can update analysis results"
  ON analysis_results FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

-- Allow updates to warnings (needed for warning management)
CREATE POLICY "Anonymous users can update warnings"
  ON warnings FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);