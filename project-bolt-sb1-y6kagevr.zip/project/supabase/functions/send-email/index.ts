import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface EmailRequest {
  to: string;
  subject: string;
  body: string;
  studentId?: string;
  submissionId?: string;
  warningNumber?: number;
}

function convertMarkdownToHTML(text: string): string {
  // Convert markdown-style formatting to HTML
  let html = text
    // Bold: **text** -> <strong>text</strong>
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Bullet points: - text -> <li>text</li>
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    // Paragraphs: double newline
    .split('\n\n')
    .map(para => {
      // Check if paragraph contains list items
      if (para.includes('<li>')) {
        return `<ul style="margin: 12px 0; padding-left: 24px;">${para}</ul>`;
      }
      return `<p style="margin: 12px 0; line-height: 1.6;">${para.replace(/\n/g, '<br>')}</p>`;
    })
    .join('');

  return html;
}

function createHTMLEmail(body: string): string {
  const htmlBody = convertMarkdownToHTML(body);

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; font-size: 16px; line-height: 1.6; color: #333; max-width: 650px; margin: 0 auto; padding: 20px;">
  ${htmlBody}
</body>
</html>`;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  // Test endpoint - GET request to test Resend configuration
  if (req.method === "GET") {
    try {
      const RESEND_API_KEY = Deno.env.get("VoiceCheck_Resend_API_KEY");

      if (!RESEND_API_KEY) {
        return new Response(
          JSON.stringify({
            success: false,
            error: "VoiceCheck_Resend_API_KEY is not configured",
          }),
          {
            status: 500,
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      // Test with a simple email to Anne@AnneHillman.com
      const testBody = "**Test email** with formatting.\n\nThis verifies that paulhillman.com is properly configured.\n\n**Key points:**\n- HTML formatting enabled\n- Bold text working\n- Better readability";

      const testPayload = {
        from: "Professor Hillman <Paul@paulhillman.com>",
        to: ["Anne@AnneHillman.com"],
        subject: "Test Email - Resend Verification",
        html: createHTMLEmail(testBody),
        text: testBody,
      };

      console.log("=== RESEND TEST ===");
      console.log("API Key present:", RESEND_API_KEY ? "Yes (length: " + RESEND_API_KEY.length + ")" : "No");
      console.log("Test payload:", JSON.stringify(testPayload, null, 2));

      const response = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${RESEND_API_KEY}`,
        },
        body: JSON.stringify(testPayload),
      });

      const responseData = await response.json();

      console.log("Response status:", response.status);
      console.log("Response headers:", JSON.stringify(Object.fromEntries(response.headers.entries()), null, 2));
      console.log("Response data:", JSON.stringify(responseData, null, 2));

      return new Response(
        JSON.stringify({
          success: response.ok,
          status: response.status,
          statusText: response.statusText,
          data: responseData,
          testPayload: testPayload,
        }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    } catch (error) {
      console.error("Test error:", error);
      return new Response(
        JSON.stringify({
          success: false,
          error: error.message,
          stack: error.stack,
        }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }
  }

  try {
    const { to, subject, body, studentId, submissionId, warningNumber }: EmailRequest = await req.json();

    const RESEND_API_KEY = Deno.env.get("VoiceCheck_Resend_API_KEY");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!RESEND_API_KEY) {
      throw new Error("VoiceCheck_Resend_API_KEY is not configured");
    }

    // Always CC Anne@AnneHillman.com
    const ccEmails = ["Anne@AnneHillman.com"];

    const emailPayload = {
      from: "Professor Hillman <Paul@paulhillman.com>",
      to: [to],
      cc: ccEmails,
      subject: subject,
      html: createHTMLEmail(body),
      text: body,
    };

    console.log("Sending email via Resend:", {
      from: emailPayload.from,
      to: emailPayload.to,
      cc: emailPayload.cc,
      subject: emailPayload.subject,
    });

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify(emailPayload),
    });

    const responseData = await response.json();

    console.log("Resend API response status:", response.status);
    console.log("Resend API response data:", JSON.stringify(responseData, null, 2));

    if (!response.ok) {
      console.error("Resend API error - Full response:", {
        status: response.status,
        statusText: response.statusText,
        data: responseData,
      });

      const errorMessage = responseData.message || responseData.error || "Failed to send email";
      throw new Error(`Resend API Error (${response.status}): ${errorMessage}`);
    }

    // Log the email to the database
    if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) {
      try {
        const emailLog = {
          student_id: studentId || null,
          submission_id: submissionId || null,
          recipient_email: to,
          cc_emails: ccEmails,
          subject: subject,
          body: body,
          warning_number: warningNumber || 0,
          resend_message_id: responseData.id,
          sent_at: new Date().toISOString(),
        };

        console.log("Logging email to database:", emailLog);

        const logResponse = await fetch(`${SUPABASE_URL}/rest/v1/email_logs`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
            "apikey": SUPABASE_SERVICE_ROLE_KEY,
            "Prefer": "return=minimal",
          },
          body: JSON.stringify(emailLog),
        });

        if (!logResponse.ok) {
          const errorText = await logResponse.text();
          console.error("Failed to log email to database:", errorText);
        } else {
          console.log("Email logged successfully");
        }

        // Create warning record and update student warning count
        if (studentId && submissionId && warningNumber) {
          console.log("Creating warning record for student:", studentId);

          const warningRecord = {
            student_id: studentId,
            submission_id: submissionId,
            warning_number: warningNumber,
            email_content: `Subject: ${subject}\n\n${body}`,
          };

          const warningResponse = await fetch(`${SUPABASE_URL}/rest/v1/warnings`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              "apikey": SUPABASE_SERVICE_ROLE_KEY,
              "Prefer": "return=minimal",
            },
            body: JSON.stringify(warningRecord),
          });

          if (!warningResponse.ok) {
            const errorText = await warningResponse.text();
            console.error("Failed to create warning record:", errorText);
          } else {
            console.log("Warning record created successfully");

            // Update student warning count
            const studentResponse = await fetch(
              `${SUPABASE_URL}/rest/v1/students?id=eq.${studentId}&select=total_warnings`,
              {
                headers: {
                  "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                  "apikey": SUPABASE_SERVICE_ROLE_KEY,
                },
              }
            );

            if (studentResponse.ok) {
              const students = await studentResponse.json();
              if (students && students.length > 0) {
                const currentWarnings = students[0].total_warnings || 0;
                const newWarningCount = currentWarnings + 1;

                console.log(`Updating student warning count: ${currentWarnings} -> ${newWarningCount}`);

                const updateResponse = await fetch(
                  `${SUPABASE_URL}/rest/v1/students?id=eq.${studentId}`,
                  {
                    method: "PATCH",
                    headers: {
                      "Content-Type": "application/json",
                      "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                      "apikey": SUPABASE_SERVICE_ROLE_KEY,
                      "Prefer": "return=minimal",
                    },
                    body: JSON.stringify({ total_warnings: newWarningCount }),
                  }
                );

                if (!updateResponse.ok) {
                  const errorText = await updateResponse.text();
                  console.error("Failed to update student warning count:", errorText);
                } else {
                  console.log("Student warning count updated successfully");
                }
              }
            }
          }
        }
      } catch (logError) {
        console.error("Error logging email:", logError);
        // Don't fail the email send if logging fails
      }
    } else {
      console.warn("Supabase credentials not available for email logging");
    }

    return new Response(
      JSON.stringify({
        success: true,
        messageId: responseData.id,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error sending email:", error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || "Failed to send email",
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
